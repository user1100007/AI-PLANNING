import { BspPlan } from '../types/bsp';

export async function analyzeBspWithAI(plan: BspPlan): Promise<string> {
  const response = await fetch('/api/ai/analyze-bsp', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ plan }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Failed to analyze BSP' }));
    throw new Error(errorData.error || 'Failed to analyze BSP');
  }

  const data = await response.json();
  return data.analysis;
}

export async function generateActionPlanWithAI(params: {
  standardTitle: string;
  indicatorCode: string;
  indicatorName: string;
  currentTarget: string;
  futureTarget: string;
}): Promise<string> {
  const response = await fetch('/api/ai/generate-action-plan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Failed to generate action plan' }));
    throw new Error(errorData.error || 'Failed to generate action plan');
  }

  const data = await response.json();
  return data.actionPlan;
}

export async function draftNarrativeWithAI(params: {
  sectionType: 'introduction' | 'progress' | 'objectives' | 'conclusion';
  schoolName: string;
  academicYear: string;
  province: string;
  highlights?: string;
}): Promise<string> {
  const response = await fetch('/api/ai/draft-narrative', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Failed to draft narrative' }));
    throw new Error(errorData.error || 'Failed to draft narrative');
  }

  const data = await response.json();
  return data.content;
}

export async function chatWithBspAI(params: {
  message: string;
  history?: { role: 'user' | 'model'; content: string }[];
  context?: string;
}): Promise<string> {
  const response = await fetch('/api/ai/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Failed to send chat message' }));
    throw new Error(errorData.error || 'Failed to send chat message');
  }

  const data = await response.json();
  return data.reply;
}
