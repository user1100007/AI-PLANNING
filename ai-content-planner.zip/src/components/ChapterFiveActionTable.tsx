import React, { useState } from 'react';
import { ChapterFiveStandardGroup, ChapterFiveActionItem } from '../data/standardFiveActionsData';
import { 
  Sparkles, 
  Search, 
  Check, 
  Plus, 
  Trash2, 
  Calendar, 
  UserCheck, 
  Coins, 
  Filter,
  CheckSquare,
  Square,
  RefreshCw,
  Layers
} from 'lucide-react';

interface ChapterFiveActionTableProps {
  groups: ChapterFiveStandardGroup[];
  onChangeGroups: (groups: ChapterFiveStandardGroup[]) => void;
  onAiAutoAssign?: () => void;
  isAiLoading?: boolean;
}

export const ChapterFiveActionTable: React.FC<ChapterFiveActionTableProps> = ({
  groups,
  onChangeGroups,
  onAiAutoAssign,
  isAiLoading = false,
}) => {
  const [selectedStdId, setSelectedStdId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingItemId, setEditingItemId] = useState<string | null>(null);

  // Calculate totals
  const allItems = groups.flatMap(g => g.items);
  const totalState = allItems.reduce((sum, item) => sum + (item.stateBudget || 0), 0);
  const totalCommunity = allItems.reduce((sum, item) => sum + (item.communityBudget || 0), 0);
  const totalPartner = allItems.reduce((sum, item) => sum + (item.partnerBudget || 0), 0);
  const grandTotal = totalState + totalCommunity + totalPartner;

  // Toggle Quarter Checkbox
  const handleToggleQuarter = (groupId: string, itemId: string, quarter: 'q1' | 'q2' | 'q3' | 'q4') => {
    const updated = groups.map(g => {
      if (g.id !== groupId) return g;
      const newItems = g.items.map(item => {
        if (item.id !== itemId) return item;
        return {
          ...item,
          [quarter]: !item[quarter],
        };
      });
      return { ...g, items: newItems };
    });
    onChangeGroups(updated);
  };

  // Update Field
  const handleUpdateItem = (groupId: string, itemId: string, field: keyof ChapterFiveActionItem, value: any) => {
    const updated = groups.map(g => {
      if (g.id !== groupId) return g;
      const newItems = g.items.map(item => {
        if (item.id !== itemId) return item;
        const updatedItem = { ...item, [field]: value };
        if (field === 'stateBudget' || field === 'communityBudget' || field === 'partnerBudget') {
          const s = field === 'stateBudget' ? (Number(value) || 0) : item.stateBudget;
          const c = field === 'communityBudget' ? (Number(value) || 0) : item.communityBudget;
          const p = field === 'partnerBudget' ? (Number(value) || 0) : item.partnerBudget;
          updatedItem.totalBudget = s + c + p;
        }
        return updatedItem;
      });
      return { ...g, items: newItems };
    });
    onChangeGroups(updated);
  };

  const filteredGroups = selectedStdId === 'all' 
    ? groups 
    : groups.filter(g => g.id === selectedStdId);

  return (
    <div className="space-y-4 font-kantumruy">
      {/* Top Summary Banner */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-gradient-to-br from-blue-700 to-indigo-800 text-white p-3.5 rounded-xl shadow-xs">
          <div className="flex items-center justify-between text-blue-200 text-xs mb-1">
            <span>សកម្មភាពអនុវត្តសរុប</span>
            <Layers className="w-4 h-4 text-amber-300" />
          </div>
          <div className="text-xl font-bold font-kantumruy">
            {allItems.length} សកម្មភាព
          </div>
          <div className="text-[11px] text-blue-200 mt-1">
            ៥ ស្តង់ដាស្នូលនៃក្រសួងអប់រំ
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 mb-1">ថវិការដ្ឋសរុប (១)</div>
          <div className="text-base sm:text-lg font-bold text-slate-800 font-mono">
            {totalState.toLocaleString()} ៛
          </div>
          <div className="text-[11px] text-emerald-600 mt-1">ថវិកាដំណើរការសាលា (PB)</div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 mb-1">សហគមន៍ & ដៃគូ (២+៣)</div>
          <div className="text-base sm:text-lg font-bold text-slate-800 font-mono">
            {(totalCommunity + totalPartner).toLocaleString()} ៛
          </div>
          <div className="text-[11px] text-blue-600 mt-1">ការចូលរួម & អង្គការ</div>
        </div>

        <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-xl shadow-2xs">
          <div className="text-xs text-emerald-700 font-medium mb-1">ថវិកាសរុបរួម (៤=១+២+៣)</div>
          <div className="text-base sm:text-lg font-bold text-emerald-900 font-mono">
            {grandTotal.toLocaleString()} ៛
          </div>
          <div className="text-[11px] text-emerald-700 mt-1">ផែនការចំណាយអនុវត្ត</div>
        </div>
      </div>

      {/* Control & Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setSelectedStdId('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              selectedStdId === 'all'
                ? 'bg-blue-600 text-white shadow-2xs font-semibold'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            ទាំងអស់ (៧១ សកម្មភាព)
          </button>
          {groups.map(g => (
            <button
              key={g.id}
              onClick={() => setSelectedStdId(g.id)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                selectedStdId === g.id
                  ? 'bg-blue-600 text-white shadow-2xs font-semibold'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {g.standardTitle.split('៖')[0]}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="ស្វែងរកសកម្មភាព ឬអ្នកទទួលខុសត្រូវ..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-none focus:border-blue-500 font-kantumruy w-48 sm:w-64"
            />
          </div>

          {onAiAutoAssign && (
            <button
              onClick={onAiAutoAssign}
              disabled={isAiLoading}
              className="flex items-center gap-1 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-semibold transition-colors disabled:opacity-50"
            >
              {isAiLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-indigo-600" />}
              <span>AI បែងចែកត្រីមាស</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Table Matching Official Format */}
      <div className="overflow-x-auto rounded-xl border border-slate-300 shadow-xs bg-white">
        <table className="w-full text-left text-xs border-collapse font-kantumruy">
          <thead>
            {/* Header Level 1 */}
            <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300 text-center">
              <th rowSpan={3} className="py-2.5 px-2 w-12 border-r border-slate-300">ល.រ</th>
              <th rowSpan={3} className="py-2.5 px-3 min-w-[220px] text-left border-r border-slate-300">
                លទ្ធផលរំពឹងទុក<br />(តាមស្តង់ដា និងសកម្មភាពគន្លឹះ)
              </th>
              <th rowSpan={3} className="py-2.5 px-3 min-w-[280px] text-left border-r border-slate-300">
                សកម្មភាពអនុវត្ត (សរុប ៧១)
              </th>
              <th colSpan={4} className="py-1 px-2 border-r border-slate-300 bg-sky-50 text-sky-950 font-bold">
                ក្របខណ្ឌពេលវេលា (ត្រីមាស)
              </th>
              <th rowSpan={2} className="py-2.5 px-3 min-w-[130px] border-r border-slate-300">
                អ្នកទទួលខុសត្រូវ
              </th>
              <th colSpan={3} className="py-1 px-2 border-r border-slate-300 bg-indigo-50 text-indigo-950 font-bold">
                ប្រភពធនធាន
              </th>
              <th rowSpan={2} className="py-2.5 px-2.5 w-28 bg-emerald-50 text-emerald-950 font-bold">
                ថវិកាសរុប
              </th>
            </tr>
            {/* Header Level 2 */}
            <tr className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-300 text-center">
              <th className="py-1 px-1.5 w-10 border-r border-slate-300">1</th>
              <th className="py-1 px-1.5 w-10 border-r border-slate-300">2</th>
              <th className="py-1 px-1.5 w-10 border-r border-slate-300">3</th>
              <th className="py-1 px-1.5 w-10 border-r border-slate-300">4</th>

              <th className="py-1 px-2 w-24 border-r border-slate-300">រដ្ឋ (១)</th>
              <th className="py-1 px-2 w-24 border-r border-slate-300">សហគមន៍ (២)</th>
              <th className="py-1 px-2 w-24 border-r border-slate-300">ដៃគូ (៣)</th>
            </tr>
            {/* Header Level 3 Codes */}
            <tr className="bg-slate-100 text-slate-500 text-[11px] border-b-2 border-slate-400 text-center font-mono">
              <td className="py-1 px-1 border-r border-slate-300">Q1</td>
              <td className="py-1 px-1 border-r border-slate-300">Q2</td>
              <td className="py-1 px-1 border-r border-slate-300">Q3</td>
              <td className="py-1 px-1 border-r border-slate-300">Q4</td>
              <td className="py-1 px-2 border-r border-slate-300 text-slate-700 font-sans">តួនាទី</td>
              <td className="py-1 px-2 border-r border-slate-300">1</td>
              <td className="py-1 px-2 border-r border-slate-300">2</td>
              <td className="py-1 px-2 border-r border-slate-300">3</td>
              <td className="py-1 px-2 font-bold text-emerald-900 bg-emerald-100/70">4=(1+2+3)</td>
            </tr>
          </thead>
          <tbody>
            {filteredGroups.map(group => {
              const groupItems = group.items.filter(item => {
                if (!searchQuery) return true;
                const q = searchQuery.toLowerCase();
                return (
                  item.expectedOutcome.toLowerCase().includes(q) ||
                  item.activities.toLowerCase().includes(q) ||
                  item.responsiblePerson.toLowerCase().includes(q) ||
                  item.code.includes(q)
                );
              });

              if (groupItems.length === 0) return null;

              const groupTotalState = groupItems.reduce((acc, i) => acc + (i.stateBudget || 0), 0);
              const groupTotalBudget = groupItems.reduce((acc, i) => acc + (i.totalBudget || 0), 0);

              return (
                <React.Fragment key={group.id}>
                  {/* Standard Banner */}
                  <tr className="bg-blue-900 text-white font-bold border-t-2 border-b border-blue-950">
                    <td colSpan={3} className="py-2.5 px-3 border-r border-blue-800 text-sm">
                      {group.standardTitle}
                    </td>
                    <td colSpan={4} className="py-1 px-2 text-center border-r border-blue-800 text-blue-200 text-xs">
                      ៤ ត្រីមាស
                    </td>
                    <td className="py-1 px-2 border-r border-blue-800 text-center text-blue-200 text-xs">
                      អ្នកទទួលខុសត្រូវ
                    </td>
                    <td className="py-1 px-2 text-right border-r border-blue-800 font-mono">
                      {groupTotalState.toLocaleString()}
                    </td>
                    <td className="py-1 px-2 text-center border-r border-blue-800 text-blue-200">-</td>
                    <td className="py-1 px-2 text-center border-r border-blue-800 text-blue-200">-</td>
                    <td className="py-1 px-2 text-right bg-blue-950 font-bold font-mono">
                      {groupTotalBudget.toLocaleString()} ៛
                    </td>
                  </tr>

                  {/* Items */}
                  {groupItems.map(item => (
                    <tr key={item.id} className="border-b border-slate-200 hover:bg-slate-50/80 transition-colors">
                      {/* Code */}
                      <td className="py-2 px-2 text-center border-r border-slate-200 font-semibold text-slate-700">
                        {item.code}
                      </td>

                      {/* Expected Outcome */}
                      <td className="py-2 px-3 border-r border-slate-200 text-slate-900 font-medium leading-relaxed">
                        <div className="text-[11px] text-blue-700 font-semibold mb-0.5">
                          {item.categoryTitle}
                        </div>
                        {item.expectedOutcome}
                      </td>

                      {/* Activities */}
                      <td className="py-2 px-3 border-r border-slate-200 text-slate-700 leading-relaxed whitespace-pre-line text-xs">
                        {item.activities}
                      </td>

                      {/* Q1 */}
                      <td className="py-1 px-1 text-center border-r border-slate-200">
                        <button
                          type="button"
                          onClick={() => handleToggleQuarter(group.id, item.id, 'q1')}
                          className={`w-6 h-6 rounded-md flex items-center justify-center mx-auto transition-colors ${
                            item.q1 ? 'bg-blue-600 text-white font-bold' : 'text-slate-300 hover:bg-slate-100'
                          }`}
                        >
                          {item.q1 ? '✓' : ''}
                        </button>
                      </td>

                      {/* Q2 */}
                      <td className="py-1 px-1 text-center border-r border-slate-200">
                        <button
                          type="button"
                          onClick={() => handleToggleQuarter(group.id, item.id, 'q2')}
                          className={`w-6 h-6 rounded-md flex items-center justify-center mx-auto transition-colors ${
                            item.q2 ? 'bg-blue-600 text-white font-bold' : 'text-slate-300 hover:bg-slate-100'
                          }`}
                        >
                          {item.q2 ? '✓' : ''}
                        </button>
                      </td>

                      {/* Q3 */}
                      <td className="py-1 px-1 text-center border-r border-slate-200">
                        <button
                          type="button"
                          onClick={() => handleToggleQuarter(group.id, item.id, 'q3')}
                          className={`w-6 h-6 rounded-md flex items-center justify-center mx-auto transition-colors ${
                            item.q3 ? 'bg-blue-600 text-white font-bold' : 'text-slate-300 hover:bg-slate-100'
                          }`}
                        >
                          {item.q3 ? '✓' : ''}
                        </button>
                      </td>

                      {/* Q4 */}
                      <td className="py-1 px-1 text-center border-r border-slate-200">
                        <button
                          type="button"
                          onClick={() => handleToggleQuarter(group.id, item.id, 'q4')}
                          className={`w-6 h-6 rounded-md flex items-center justify-center mx-auto transition-colors ${
                            item.q4 ? 'bg-blue-600 text-white font-bold' : 'text-slate-300 hover:bg-slate-100'
                          }`}
                        >
                          {item.q4 ? '✓' : ''}
                        </button>
                      </td>

                      {/* Responsible Person */}
                      <td className="py-1.5 px-2 border-r border-slate-200">
                        <input
                          type="text"
                          value={item.responsiblePerson}
                          onChange={(e) => handleUpdateItem(group.id, item.id, 'responsiblePerson', e.target.value)}
                          placeholder="អ្នកទទួលខុសត្រូវ..."
                          className="w-full p-1 text-xs bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-slate-300 focus:border-blue-500 rounded outline-none font-medium text-slate-800"
                        />
                      </td>

                      {/* State Budget */}
                      <td className="py-1.5 px-1.5 text-right border-r border-slate-200">
                        <input
                          type="number"
                          value={item.stateBudget || ''}
                          onChange={(e) => handleUpdateItem(group.id, item.id, 'stateBudget', e.target.value)}
                          placeholder="0"
                          className="w-full text-right p-1 text-xs bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-slate-300 focus:border-blue-500 rounded outline-none font-mono text-slate-800 font-semibold"
                        />
                      </td>

                      {/* Community Budget */}
                      <td className="py-1.5 px-1.5 text-right border-r border-slate-200">
                        <input
                          type="number"
                          value={item.communityBudget || ''}
                          onChange={(e) => handleUpdateItem(group.id, item.id, 'communityBudget', e.target.value)}
                          placeholder="0"
                          className="w-full text-right p-1 text-xs bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-slate-300 focus:border-blue-500 rounded outline-none font-mono text-slate-700"
                        />
                      </td>

                      {/* Partner Budget */}
                      <td className="py-1.5 px-1.5 text-right border-r border-slate-200">
                        <input
                          type="number"
                          value={item.partnerBudget || ''}
                          onChange={(e) => handleUpdateItem(group.id, item.id, 'partnerBudget', e.target.value)}
                          placeholder="0"
                          className="w-full text-right p-1 text-xs bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-slate-300 focus:border-blue-500 rounded outline-none font-mono text-slate-700"
                        />
                      </td>

                      {/* Total Budget */}
                      <td className="py-2 px-2 text-right bg-emerald-50/50 font-bold font-mono text-emerald-800">
                        {item.totalBudget > 0 ? item.totalBudget.toLocaleString() : '-'}
                      </td>
                    </tr>
                  ))}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
