import React, { useState } from 'react';
import { 
  Sparkles, 
  Wand2, 
  Maximize2, 
  FileCheck, 
  ListOrdered, 
  Copy, 
  Check, 
  Send, 
  TrendingUp, 
  RefreshCw,
  HelpCircle,
  ChevronRight
} from 'lucide-react';
import { ActionMatrixItem } from '../types/plan';
import { ActionMatrixTable } from './ActionMatrixTable';
import { StandardCategory } from '../data/standardFourData';
import { StandardFourTable } from './StandardFourTable';
import { ChapterFiveStandardGroup } from '../data/standardFiveActionsData';
import { ChapterFiveActionTable } from './ChapterFiveActionTable';

interface SectionEditorProps {
  sectionId: string;
  sectionCode?: string;
  title: string;
  parentTitle?: string;
  content: string;
  onChangeContent: (newContent: string) => void;
  onAiRefine: (action: string, customInstruction?: string) => Promise<void>;
  isLoadingAi: boolean;
  actionMatrix?: ActionMatrixItem[];
  onChangeActionMatrix?: (items: ActionMatrixItem[]) => void;
  onGenerateAiRows?: () => void;
  standardTargets?: StandardCategory[];
  onChangeStandardTargets?: (standards: StandardCategory[]) => void;
  onAiAutoFillStandards?: () => void;
  chapterFiveActions?: ChapterFiveStandardGroup[];
  onChangeChapterFiveActions?: (groups: ChapterFiveStandardGroup[]) => void;
}

export const SectionEditor: React.FC<SectionEditorProps> = ({
  sectionId,
  sectionCode,
  title,
  parentTitle,
  content,
  onChangeContent,
  onAiRefine,
  isLoadingAi,
  actionMatrix,
  onChangeActionMatrix,
  onGenerateAiRows,
  standardTargets,
  onChangeStandardTargets,
  onAiAutoFillStandards,
  chapterFiveActions,
  onChangeChapterFiveActions,
}) => {
  const [customPrompt, setCustomPrompt] = useState('');
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [copied, setCopied] = useState(false);
  const [actionViewType, setActionViewType] = useState<'detailed71' | 'concise'>('detailed71');

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customPrompt.trim()) return;
    onAiRefine('custom', customPrompt.trim());
    setCustomPrompt('');
    setShowCustomInput(false);
  };

  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
  const isActionChapter = sectionId === 'sec-5';
  const isStandardFourChapter = sectionId === 'sec-4';

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Top Header & Breadcrumbs */}
      <div className="px-5 py-4 border-b border-slate-100 bg-slate-50/60 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium mb-1">
            <span>ផ្ទាំងឯកសារ</span>
            <ChevronRight className="w-3 h-3 text-slate-400" />
            {parentTitle && (
              <>
                <span className="text-slate-600">{parentTitle}</span>
                <ChevronRight className="w-3 h-3 text-slate-400" />
              </>
            )}
            <span className="text-blue-600 font-semibold">{sectionCode ? `${sectionCode}. ` : ''}{title}</span>
          </div>

          <h2 className="text-base sm:text-lg font-bold text-slate-900 font-kantumruy">
            {sectionCode ? `${sectionCode}. ` : ''}{title}
          </h2>
        </div>

        {/* Word count & copy */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 bg-slate-100 px-2.5 py-1 rounded-lg">
            {wordCount} ពាក្យ | {content.length} តួអក្សរ
          </span>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'បានចម្លង' : 'ចម្លង'}</span>
          </button>
        </div>
      </div>

      {/* AI Assistance Toolbar */}
      <div className="p-3 bg-gradient-to-r from-blue-50/70 via-indigo-50/40 to-slate-50 border-b border-blue-100/70">
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="flex items-center gap-1 text-blue-700 font-semibold mr-1 shrink-0">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            ជំនួយការ AI:
          </span>

          <button
            onClick={() => onAiRefine('generate')}
            disabled={isLoadingAi}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium shadow-2xs transition-colors disabled:opacity-50"
          >
            {isLoadingAi ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Wand2 className="w-3 h-3" />}
            <span>សរសេរស្វ័យប្រវត្ត</span>
          </button>

          <button
            onClick={() => onAiRefine('formalize')}
            disabled={isLoadingAi}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-slate-50 text-slate-700 font-medium border border-slate-200 shadow-2xs transition-colors disabled:opacity-50"
          >
            <FileCheck className="w-3 h-3 text-indigo-600" />
            <span>កែសម្រួលភាសារដ្ឋបាល</span>
          </button>

          <button
            onClick={() => onAiRefine('expand')}
            disabled={isLoadingAi}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-slate-50 text-slate-700 font-medium border border-slate-200 shadow-2xs transition-colors disabled:opacity-50"
          >
            <Maximize2 className="w-3 h-3 text-emerald-600" />
            <span>ពង្រីកខ្លឹមសារលម្អិត</span>
          </button>

          <button
            onClick={() => onAiRefine('add_indicators')}
            disabled={isLoadingAi}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-slate-50 text-slate-700 font-medium border border-slate-200 shadow-2xs transition-colors disabled:opacity-50"
          >
            <TrendingUp className="w-3 h-3 text-amber-600" />
            <span>បន្ថែមសូចនាករ/KPIs</span>
          </button>

          <button
            onClick={() => setShowCustomInput(!showCustomInput)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium border shadow-2xs transition-colors ${
              showCustomInput 
                ? 'bg-blue-100 text-blue-800 border-blue-300' 
                : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
            }`}
          >
            <HelpCircle className="w-3 h-3 text-purple-600" />
            <span>បញ្ជា AI តាមចិត្ត</span>
          </button>
        </div>

        {/* Custom prompt input drawer */}
        {showCustomInput && (
          <form onSubmit={handleCustomSubmit} className="mt-2.5 flex items-center gap-2">
            <input
              type="text"
              placeholder="ឧ. បន្ថែមស្ថិតិសិស្សប្រឡងជាប់ ៩៥% និងទិន្នន័យត្រីមាសទី២..."
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              className="flex-1 px-3 py-1.5 text-xs bg-white border border-blue-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-400 font-kantumruy"
            />
            <button
              type="submit"
              disabled={isLoadingAi || !customPrompt.trim()}
              className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs disabled:opacity-50"
            >
              <Send className="w-3 h-3" />
              <span>ផ្ញើ</span>
            </button>
          </form>
        )}
      </div>

      {/* Main Text Content Area */}
      <div className="p-5">
        <label className="block text-xs font-medium text-slate-500 mb-1.5">
          ខ្លឹមសារអត្ថបទ (កែប្រែដោយផ្ទាល់ ឬប្រើជំនួយការ AI ខាងលើ)៖
        </label>
        <textarea
          value={content}
          onChange={(e) => onChangeContent(e.target.value)}
          placeholder="បញ្ចូលខ្លឹមសារនៅទីនេះ ឬចុចប៊ូតុង 'សរសេរស្វ័យប្រវត្ត' ដើម្បីឱ្យ AI ជួយរៀបចំ..."
          rows={12}
          className="w-full p-4 text-sm leading-relaxed text-slate-800 bg-slate-50/30 hover:bg-slate-50/60 focus:bg-white border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 font-kantumruy transition-all resize-y shadow-inner"
        />
      </div>

      {/* Embedded Action Matrix Table for Section 5 */}
      {isActionChapter && (
        <div className="p-5 border-t border-slate-200 bg-slate-50/40 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-800 font-kantumruy">
                តារាងម៉ាទ្រីសសកម្មភាពអនុវត្ត (Chapter 5 Implementation Matrix)
              </h3>
              <p className="text-xs text-slate-500">
                តារាងលម្អិត ៧១ សកម្មភាពអនុវត្តតាមស្តង់ដាទាំង ៥ និងសកម្មភាពគន្លឹះ នៃក្រសួងអប់រំ យុវជន និងកីឡា
              </p>
            </div>

            <div className="flex items-center bg-white p-1 rounded-lg border border-slate-200 text-xs font-medium">
              <button
                type="button"
                onClick={() => setActionViewType('detailed71')}
                className={`px-3 py-1.5 rounded-md transition-colors ${
                  actionViewType === 'detailed71'
                    ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                តារាងផ្លូវការ ៧១ សកម្មភាព
              </button>
              <button
                type="button"
                onClick={() => setActionViewType('concise')}
                className={`px-3 py-1.5 rounded-md transition-colors ${
                  actionViewType === 'concise'
                    ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                តារាងសង្ខេប
              </button>
            </div>
          </div>

          {actionViewType === 'detailed71' && chapterFiveActions && onChangeChapterFiveActions ? (
            <ChapterFiveActionTable
              groups={chapterFiveActions}
              onChangeGroups={onChangeChapterFiveActions}
              onAiAutoAssign={() => {
                // Friendly AI auto-assignment toast or quick tweak
              }}
              isAiLoading={isLoadingAi}
            />
          ) : actionMatrix && onChangeActionMatrix ? (
            <ActionMatrixTable
              items={actionMatrix}
              onChange={onChangeActionMatrix}
              onGenerateAiRows={onGenerateAiRows || (() => {})}
              isGenerating={isLoadingAi}
            />
          ) : null}
        </div>
      )}

      {/* Embedded Official Standards & Indicators Budget Table for Section 4 */}
      {isStandardFourChapter && standardTargets && onChangeStandardTargets && (
        <div className="p-5 border-t border-slate-200 bg-slate-50/40">
          <div className="mb-4">
            <h3 className="text-sm font-bold text-slate-800 font-kantumruy">
              តារាងស្តង់ដា និងសូចនាករគ្រោងថវិកា (ឆ្នាំ N+1) តាមនិយាមក្រសួងអប់រំ យុវជន និងកីឡា
            </h3>
            <p className="text-xs text-slate-500">
              តារាងគណនាសូចនាករស្តង់ដាទាំង ៥ និងថវិកាអនុវត្ត (ថវិការដ្ឋ និងថវិកាក្រៅពីរដ្ឋ) សរុប ១៣,៩០៣,១០០ រៀល
            </p>
          </div>
          <StandardFourTable
            standards={standardTargets}
            onChangeStandards={onChangeStandardTargets}
            onAiAutoFill={onAiAutoFillStandards}
            isAiLoading={isLoadingAi}
          />
        </div>
      )}
    </div>
  );
};
