import React from 'react';
import { 
  Sparkles, 
  FileText, 
  Printer, 
  Copy, 
  Download, 
  RotateCcw, 
  Eye, 
  Edit3,
  Check,
  BookOpen,
  CheckCircle2,
  RefreshCw,
  AlertCircle,
  CloudCheck
} from 'lucide-react';

interface NavbarProps {
  onOpenGenerator: () => void;
  onOpenPlanList: () => void;
  onPrint: () => void;
  onCopyAll: () => void;
  onDownloadDoc: () => void;
  onReset: () => void;
  viewMode: 'edit' | 'preview';
  setViewMode: (mode: 'edit' | 'preview') => void;
  isCopied: boolean;
  totalWords: number;
  saveStatus: 'saved' | 'saving' | 'error';
  lastSavedText: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenGenerator,
  onOpenPlanList,
  onPrint,
  onCopyAll,
  onDownloadDoc,
  onReset,
  viewMode,
  setViewMode,
  isCopied,
  totalWords,
  saveStatus,
  lastSavedText,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Left Branding */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 via-indigo-600 to-sky-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight font-kantumruy">
                ផែនការប្រតិបត្តិ <span className="text-blue-600 font-normal">AI</span>
              </h1>
              <span className="hidden sm:inline-block px-2 py-0.5 text-[11px] font-medium bg-blue-50 text-blue-700 rounded-full border border-blue-200/60">
                MoEYS AOP Standard
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden sm:block">
              កម្មវិធីសរសេរ និងរៀបចំផែនការប្រតិបត្តិស្វ័យប្រវត្ត
            </p>
          </div>
        </div>

        {/* Center View Switcher & Auto-save Indicator */}
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-medium">
            <button
              onClick={() => setViewMode('edit')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'edit'
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>កែសម្រួល</span>
            </button>
            <button
              onClick={() => setViewMode('preview')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'preview'
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>ទម្រង់ផ្លូវការ</span>
            </button>
          </div>

          {/* Auto-save Status Indicator */}
          <div className="hidden lg:flex items-center transition-all">
            {saveStatus === 'saving' && (
              <div className="flex items-center gap-1.5 text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200 text-xs font-medium">
                <RefreshCw className="w-3 h-3 animate-spin text-amber-600" />
                <span>កំពុងរក្សាទុក...</span>
              </div>
            )}
            {saveStatus === 'saved' && (
              <div className="flex items-center gap-1.5 text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 text-xs font-medium animate-in fade-in duration-200">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>បានរក្សាទុក {lastSavedText}</span>
              </div>
            )}
            {saveStatus === 'error' && (
              <div className="flex items-center gap-1.5 text-rose-700 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200 text-xs font-medium">
                <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                <span>បរាជ័យក្នុងការរក្សាទុក</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Action Buttons */}
        <div className="flex items-center gap-2">
          {/* Multi-Plan Manager Button */}
          <button
            onClick={onOpenPlanList}
            title="គ្រប់គ្រង ឬបង្កើតផែនការបន្ថែមក្នុង Firestore"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold transition-all border border-slate-200"
          >
            <BookOpen className="w-4 h-4 text-blue-600" />
            <span className="hidden sm:inline">បញ្ជីផែនការ (Firestore)</span>
            <span className="sm:hidden">ផែនការ</span>
          </button>

          {/* AI Generator Button */}
          <button
            onClick={onOpenGenerator}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs sm:text-sm font-semibold shadow-md shadow-blue-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
            <span className="hidden sm:inline">បង្កើតដោយ AI ស្វ័យប្រវត្ត</span>
            <span className="sm:hidden">AI បង្កើត</span>
          </button>

          {/* Print / Export */}
          <div className="flex items-center border-l border-slate-200 pl-2 gap-1.5">
            <button
              onClick={onPrint}
              title="បោះពុម្ព ឬរក្សាទុកជា PDF (Print / Save as PDF)"
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors border border-transparent hover:border-slate-200"
            >
              <Printer className="w-4 h-4" />
            </button>

            <button
              onClick={onCopyAll}
              title="ចម្លងអត្ថបទទាំងអស់ (Copy All for Google Docs)"
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors border border-transparent hover:border-slate-200 relative"
            >
              {isCopied ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>

            <button
              onClick={onDownloadDoc}
              title="ទាញយកឯកសារ Word / HTML (.doc)"
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors border border-transparent hover:border-slate-200"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={onReset}
              title="កំណត់ឡើងវិញជាគំរូដើម (Reset to Default)"
              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors border border-transparent hover:border-rose-200"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
