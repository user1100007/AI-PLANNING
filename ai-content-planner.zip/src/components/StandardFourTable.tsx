import React, { useState } from 'react';
import { 
  StandardCategory, 
  IndicatorRow 
} from '../data/standardFourData';
import { 
  Sparkles, 
  Search, 
  Filter, 
  Coins, 
  Calculator, 
  Check, 
  Edit3, 
  TrendingUp,
  FileSpreadsheet,
  ChevronDown,
  RefreshCw
} from 'lucide-react';

interface StandardFourTableProps {
  standards: StandardCategory[];
  onChangeStandards: (standards: StandardCategory[]) => void;
  onAiAutoFill?: () => void;
  isAiLoading?: boolean;
}

export const StandardFourTable: React.FC<StandardFourTableProps> = ({
  standards,
  onChangeStandards,
  onAiAutoFill,
  isAiLoading = false,
}) => {
  const [selectedStandardId, setSelectedStandardId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingRowId, setEditingRowId] = useState<string | null>(null);

  // Calculate totals
  const totalStateBudget = standards.reduce((acc, std) => {
    return acc + std.rows.reduce((rAcc, row) => rAcc + (row.isCategoryHeader ? 0 : (row.stateBudget || 0)), 0);
  }, 0);

  const totalNonStateBudget = standards.reduce((acc, std) => {
    return acc + std.rows.reduce((rAcc, row) => rAcc + (row.isCategoryHeader ? 0 : (row.nonStateBudget || 0)), 0);
  }, 0);

  const grandTotal = totalStateBudget + totalNonStateBudget;

  const handleUpdateRow = (stdId: string, rowId: string, field: keyof IndicatorRow, value: any) => {
    const updated = standards.map(std => {
      if (std.id !== stdId) return std;
      const newRows = std.rows.map(row => {
        if (row.id !== rowId) return row;
        return {
          ...row,
          [field]: field === 'stateBudget' || field === 'nonStateBudget' ? Number(value) || 0 : value,
        };
      });
      return { ...std, rows: newRows };
    });
    onChangeStandards(updated);
  };

  const filteredStandards = selectedStandardId === 'all' 
    ? standards 
    : standards.filter(s => s.id === selectedStandardId);

  return (
    <div className="space-y-5 font-kantumruy">
      {/* Overview Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
        <div className="bg-gradient-to-br from-blue-700 to-indigo-800 text-white p-3 rounded-xl shadow-xs col-span-2 sm:col-span-1 lg:col-span-2">
          <div className="flex items-center justify-between text-blue-200 text-xs mb-1">
            <span>ថវិកាសរុបរួម (N+1)</span>
            <Coins className="w-4 h-4 text-amber-300" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-kantumruy">
            {grandTotal.toLocaleString()} រៀល
          </div>
          <div className="text-[11px] text-blue-200 mt-1 flex justify-between">
            <span>រដ្ឋ៖ {totalStateBudget.toLocaleString()}</span>
            <span>ក្រៅពីរដ្ឋ៖ {totalNonStateBudget.toLocaleString()}</span>
          </div>
        </div>

        {standards.map((std, idx) => {
          const stdBudget = std.rows.reduce((sum, r) => sum + (r.isCategoryHeader ? 0 : (r.stateBudget || 0) + (r.nonStateBudget || 0)), 0);
          return (
            <div 
              key={std.id}
              onClick={() => setSelectedStandardId(selectedStandardId === std.id ? 'all' : std.id)}
              className={`p-2.5 rounded-xl border cursor-pointer transition-all ${
                selectedStandardId === std.id 
                  ? 'bg-blue-50 border-blue-400 shadow-xs' 
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="text-[11px] text-slate-500 truncate">{std.code}</div>
              <div className="text-xs font-bold text-slate-800 truncate">{std.title}</div>
              <div className="text-xs font-semibold text-emerald-600 mt-1">
                {stdBudget.toLocaleString()} ៛
              </div>
            </div>
          );
        })}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setSelectedStandardId('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              selectedStandardId === 'all'
                ? 'bg-blue-600 text-white shadow-2xs font-semibold'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            ទាំងអស់ (៥ ស្តង់ដា)
          </button>
          {standards.map(s => (
            <button
              key={s.id}
              onClick={() => setSelectedStandardId(s.id)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                selectedStandardId === s.id
                  ? 'bg-blue-600 text-white shadow-2xs font-semibold'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {s.code}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="ស្វែងរកសូចនាករ..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-none focus:border-blue-500 font-kantumruy w-44 sm:w-56"
            />
          </div>

          {onAiAutoFill && (
            <button
              onClick={onAiAutoFill}
              disabled={isAiLoading}
              className="flex items-center gap-1 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-semibold transition-colors disabled:opacity-50"
            >
              {isAiLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-indigo-600" />}
              <span>AI ពិនិត្យគោលដៅ</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Standard & Indicators Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-300 shadow-xs bg-white">
        <table className="w-full text-left text-xs border-collapse font-kantumruy">
          <thead>
            {/* Header Level 1 */}
            <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
              <th rowSpan={2} className="py-2.5 px-2 text-center w-12 border-r border-slate-300">ល.រ</th>
              <th rowSpan={2} className="py-2.5 px-3 min-w-[280px] border-r border-slate-300">ស្តង់ដា និងសូចនាករ</th>
              <th rowSpan={2} className="py-2.5 px-2 text-center w-14 border-r border-slate-300">ឯកតា</th>
              <th rowSpan={2} className="py-2.5 px-2.5 text-center min-w-[130px] border-r border-slate-300">
                លទ្ធផលសូចនាករ<br />ឆ្នាំបច្ចុប្បន្ន (N)
              </th>
              <th rowSpan={2} className="py-2.5 px-2.5 text-center min-w-[130px] border-r border-slate-300">
                គោលដៅសូចនាករ<br />គ្រោងថវិកា (N+1)
              </th>
              <th colSpan={3} className="py-2 px-2 text-center border-b border-slate-300 bg-blue-50/70 text-blue-900 font-bold">
                ឆ្នាំគ្រោងថវិកា (ឆ្នាំ N+1)
              </th>
            </tr>
            {/* Header Level 2 */}
            <tr className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-300 text-center">
              <th className="py-1.5 px-2 w-28 border-r border-slate-300">ថវិការដ្ឋ (៛)</th>
              <th className="py-1.5 px-2 w-28 border-r border-slate-300">ថវិកាក្រៅពីរដ្ឋ (៛)</th>
              <th className="py-1.5 px-2 w-28 bg-emerald-50 text-emerald-900 font-bold">ថវិកាសរុប (៛)</th>
            </tr>
            {/* Grand Total Row directly underneath header matching official MoEYS standard */}
            <tr className="bg-amber-50 text-amber-950 font-bold border-b-2 border-slate-400">
              <th colSpan={5} className="py-2 px-4 text-right border-r border-slate-300 uppercase">
                ថវិកាសរុបរួមទាំងអស់ (Grand Total)៖
              </th>
              <td className="py-2 px-2 text-right border-r border-slate-300 font-mono">
                {totalStateBudget.toLocaleString()}
              </td>
              <td className="py-2 px-2 text-right border-r border-slate-300 font-mono">
                {totalNonStateBudget > 0 ? totalNonStateBudget.toLocaleString() : '-'}
              </td>
              <td className="py-2 px-2 text-right bg-emerald-100 text-emerald-950 font-bold font-mono">
                {grandTotal.toLocaleString()}
              </td>
            </tr>
          </thead>
          <tbody>
            {filteredStandards.map((std) => {
              const stdTotalState = std.rows.reduce((s, r) => s + (r.isCategoryHeader ? 0 : (r.stateBudget || 0)), 0);
              const stdTotalNonState = std.rows.reduce((s, r) => s + (r.isCategoryHeader ? 0 : (r.nonStateBudget || 0)), 0);
              const stdTotal = stdTotalState + stdTotalNonState;

              return (
                <React.Fragment key={std.id}>
                  {/* Standard Category Main Section Row */}
                  <tr className="bg-blue-900 text-white font-bold border-t-2 border-b border-blue-950">
                    <td colSpan={3} className="py-2 px-3 border-r border-blue-800">
                      {std.code}៖ {std.title} ({std.subtitle})
                    </td>
                    <td className="py-2 px-2 text-center border-r border-blue-800">-</td>
                    <td className="py-2 px-2 text-center border-r border-blue-800">-</td>
                    <td className="py-2 px-2 text-right border-r border-blue-800 font-mono">
                      {stdTotalState.toLocaleString()}
                    </td>
                    <td className="py-2 px-2 text-right border-r border-blue-800 font-mono">
                      {stdTotalNonState > 0 ? stdTotalNonState.toLocaleString() : '-'}
                    </td>
                    <td className="py-2 px-2 text-right bg-blue-950 font-bold font-mono">
                      {stdTotal.toLocaleString()}
                    </td>
                  </tr>

                  {/* Standard Rows */}
                  {std.rows.map((row) => {
                    if (searchQuery && !row.title.toLowerCase().includes(searchQuery.toLowerCase())) {
                      return null;
                    }

                    const rowTotal = (row.stateBudget || 0) + (row.nonStateBudget || 0);

                    // Category Header within standard (e.g. "១. ការប្រមូលកុមារចូលរៀន")
                    if (row.isCategoryHeader) {
                      return (
                        <tr key={row.id} className="bg-slate-100/90 text-slate-900 font-bold border-b border-slate-300">
                          <td className="py-2 px-2 text-center border-r border-slate-300 font-semibold">{row.code}</td>
                          <td colSpan={2} className="py-2 px-3 border-r border-slate-300">{row.title}</td>
                          <td className="py-2 px-2 text-center border-r border-slate-300 text-slate-400">-</td>
                          <td className="py-2 px-2 text-center border-r border-slate-300 text-slate-400">-</td>
                          <td className="py-2 px-2 text-right border-r border-slate-300 font-mono text-slate-700">
                            {row.stateBudget > 0 ? row.stateBudget.toLocaleString() : '-'}
                          </td>
                          <td className="py-2 px-2 text-right border-r border-slate-300 font-mono text-slate-700">
                            {row.nonStateBudget > 0 ? row.nonStateBudget.toLocaleString() : '-'}
                          </td>
                          <td className="py-2 px-2 text-right bg-slate-200/70 font-bold font-mono text-slate-800">
                            {rowTotal > 0 ? rowTotal.toLocaleString() : '-'}
                          </td>
                        </tr>
                      );
                    }

                    // Indicator Data Row
                    return (
                      <tr key={row.id} className="border-b border-slate-200 hover:bg-slate-50/70 transition-colors">
                        <td className="py-1.5 px-2 text-center border-r border-slate-200 text-slate-500 font-medium">
                          {row.code}
                        </td>
                        <td className="py-1.5 px-3 border-r border-slate-200 text-slate-800">
                          {row.title}
                        </td>
                        <td className="py-1.5 px-2 text-center border-r border-slate-200 text-slate-600 font-medium">
                          {row.unit || '-'}
                        </td>
                        <td className="py-1 px-1.5 text-center border-r border-slate-200">
                          <input
                            type="text"
                            value={row.currentN}
                            onChange={(e) => handleUpdateRow(std.id, row.id, 'currentN', e.target.value)}
                            placeholder="-"
                            className="w-full text-center py-1 px-1 text-xs bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-slate-300 focus:border-blue-500 rounded outline-none font-medium"
                          />
                        </td>
                        <td className="py-1 px-1.5 text-center border-r border-slate-200">
                          <input
                            type="text"
                            value={row.targetN1}
                            onChange={(e) => handleUpdateRow(std.id, row.id, 'targetN1', e.target.value)}
                            placeholder="-"
                            className="w-full text-center py-1 px-1 text-xs bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-blue-300 focus:border-blue-500 rounded outline-none font-bold text-blue-700"
                          />
                        </td>
                        <td className="py-1 px-1.5 text-right border-r border-slate-200">
                          <input
                            type="number"
                            value={row.stateBudget || ''}
                            onChange={(e) => handleUpdateRow(std.id, row.id, 'stateBudget', e.target.value)}
                            placeholder="0"
                            className="w-full text-right py-1 px-1 text-xs bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-slate-300 focus:border-blue-500 rounded outline-none font-mono text-slate-800"
                          />
                        </td>
                        <td className="py-1 px-1.5 text-right border-r border-slate-200">
                          <input
                            type="number"
                            value={row.nonStateBudget || ''}
                            onChange={(e) => handleUpdateRow(std.id, row.id, 'nonStateBudget', e.target.value)}
                            placeholder="0"
                            className="w-full text-right py-1 px-1 text-xs bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-slate-300 focus:border-blue-500 rounded outline-none font-mono text-slate-800"
                          />
                        </td>
                        <td className="py-1.5 px-2 text-right bg-emerald-50/40 font-bold font-mono text-emerald-800">
                          {rowTotal > 0 ? rowTotal.toLocaleString() : '-'}
                        </td>
                      </tr>
                    );
                  })}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
