import React, { useState } from 'react';
import { PlanData } from '../types/plan';
import { 
  FolderKanban, 
  Plus, 
  Trash2, 
  Calendar, 
  School, 
  X, 
  Check, 
  Cloud, 
  ExternalLink,
  Coins,
  Layers,
  Sparkles
} from 'lucide-react';

interface PlanListModalProps {
  isOpen: boolean;
  onClose: () => void;
  plans: PlanData[];
  currentPlanId: string;
  onSelectPlan: (plan: PlanData) => void;
  onCreateNewPlan: (title: string, academicYear: string) => Promise<void>;
  onDeletePlan: (planId: string) => Promise<void>;
}

export const PlanListModal: React.FC<PlanListModalProps> = ({
  isOpen,
  onClose,
  plans,
  currentPlanId,
  onSelectPlan,
  onCreateNewPlan,
  onDeletePlan,
}) => {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newYear, setNewYear] = useState('ឆ្នាំសិក្សា ២០២៥-២០២៦');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    setIsSubmitting(true);
    try {
      await onCreateNewPlan(newTitle.trim(), newYear.trim());
      setNewTitle('');
      setShowCreateForm(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200 font-kantumruy">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-blue-800 via-indigo-700 to-sky-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-xs flex items-center justify-center border border-white/20">
              <FolderKanban className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold">
                បញ្ជីផែនការប្រតិបត្តិក្នុង Firestore Cloud
              </h3>
              <p className="text-xs text-blue-100 flex items-center gap-1.5 mt-0.5">
                <Cloud className="w-3.5 h-3.5 text-emerald-300" />
                <span>រក្សាទុកស្វ័យប្រវត្តក្នុង Cloud Database (គ្រប់គ្រងបានច្រើនផែនការ/ច្រើនឆ្នាំ)</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Action button to create a new plan */}
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700">
              ផែនការទាំងអស់ ({plans.length})
            </span>
            <button
              onClick={() => setShowCreateForm(!showCreateForm)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>បង្កើតផែនការថ្មី</span>
            </button>
          </div>

          {/* Create Form Drawer */}
          {showCreateForm && (
            <form onSubmit={handleCreate} className="p-4 bg-blue-50/70 rounded-xl border border-blue-200 space-y-3">
              <h4 className="text-xs font-bold text-blue-900">បង្កើតផែនការថ្មីសម្រាប់ឆ្នាំបន្ទាប់</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">ចំណងជើងផែនការ *</label>
                  <input
                    type="text"
                    required
                    placeholder="ឧ. ផែនការប្រតិបត្តិ ២០២៥-២០២៦ ឬ ផែនការកែលម្អ..."
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:border-blue-500 font-kantumruy"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">ឆ្នាំសិក្សា/កាលបរិច្ឆេទ</label>
                  <input
                    type="text"
                    required
                    value={newYear}
                    onChange={(e) => setNewYear(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:border-blue-500 font-kantumruy"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="px-3 py-1 text-xs text-slate-600 hover:bg-slate-200/60 rounded-md transition-colors"
                >
                  បោះបង់
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || !newTitle.trim()}
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? 'កំពុងបង្កើត...' : 'បង្កើត និងបើក'}
                </button>
              </div>
            </form>
          )}

          {/* Plans List */}
          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
            {plans.map((p) => {
              const isCurrent = p.id === currentPlanId;
              const totalBudget = (p.chapterFiveActions || []).flatMap(g => g.items).reduce((s, i) => s + (i.totalBudget || 0), 0) || 13903100;
              const actionsCount = (p.chapterFiveActions || []).flatMap(g => g.items).length || 71;

              return (
                <div
                  key={p.id}
                  onClick={() => {
                    onSelectPlan(p);
                    onClose();
                  }}
                  className={`p-4 rounded-xl border cursor-pointer transition-all flex flex-wrap items-center justify-between gap-3 ${
                    isCurrent
                      ? 'bg-blue-50/80 border-blue-400 shadow-xs ring-1 ring-blue-400/40'
                      : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-sm font-bold text-slate-900 truncate">
                        {p.title}
                      </h4>
                      {isCurrent && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-600 text-white">
                          កំពុងបើក
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                      <span className="flex items-center gap-1 text-slate-700">
                        <School className="w-3.5 h-3.5 text-blue-600" />
                        {p.schoolName}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1 text-slate-700">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {p.academicYear}
                      </span>
                      <span>•</span>
                      <span className="text-emerald-700 font-semibold font-mono">
                        {totalBudget.toLocaleString()} ៛ ({actionsCount} សកម្មភាព)
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                    {plans.length > 1 && (
                      <button
                        onClick={() => {
                          if (window.confirm(`តើអ្នកពិតជាចង់លុបផែនការ "${p.title}" មែនទេ?`)) {
                            onDeletePlan(p.id);
                          }
                        }}
                        title="លុបផែនការនេះ"
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
            <Cloud className="w-4 h-4 text-emerald-600" />
            <span>ទិន្នន័យទាំងអស់ត្រូវបានរក្សាទុកដោយស្វ័យប្រវត្តក្នុង Firestore</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg font-semibold transition-colors"
          >
            បិទ
          </button>
        </div>
      </div>
    </div>
  );
};
