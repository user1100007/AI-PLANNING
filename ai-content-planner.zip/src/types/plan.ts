import { StandardCategory } from '../data/standardFourData';
import { ChapterFiveStandardGroup } from '../data/standardFiveActionsData';

export interface PlanItem {
  id: string;
  title: string;
  content: string;
}

export interface PlanSubsection {
  id: string;
  code: string;
  title: string;
  content: string;
  items?: PlanItem[];
}

export interface PlanSection {
  id: string;
  code: string;
  title: string;
  content: string;
  subsections?: PlanSubsection[];
}

export interface ActionMatrixItem {
  id: string;
  activity: string;
  indicator: string;
  timeline: string;
  budget: string;
  budgetSource: string;
  responsiblePerson: string;
}

export interface PlanData {
  id: string;
  title: string;
  subtitle: string;
  schoolName: string;
  academicYear: string;
  location: string;
  schoolType: string;
  preparedBy: string;
  approvedBy: string;
  createdDate: string;
  sections: PlanSection[];
  actionMatrix: ActionMatrixItem[];
  standardTargets?: StandardCategory[];
  chapterFiveActions?: ChapterFiveStandardGroup[];
  userId?: string;
  updatedAt?: string;
}

export interface PlanGeneratorParams {
  schoolName: string;
  academicYear: string;
  location: string;
  schoolType: string;
  priorities: string;
  challenges: string;
  targetGoals: string;
}
