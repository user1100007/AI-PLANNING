import React, { useState, useEffect } from 'react';
import { DEFAULT_PLAN_DATA } from './data/defaultPlan';
import { PlanData, PlanGeneratorParams, PlanSection, PlanSubsection, PlanItem } from './types/plan';
import { Navbar } from './components/Navbar';
import { SidebarOutline } from './components/SidebarOutline';
import { SectionEditor } from './components/SectionEditor';
import { FormalDocumentView } from './components/FormalDocumentView';
import { PlanGeneratorModal } from './components/PlanGeneratorModal';
import { PlanListModal } from './components/PlanListModal';
import { 
  savePlanToFirestore, 
  listPlansFromFirestore, 
  createNewPlanInFirestore, 
  deletePlanFromFirestore 
} from './services/planFirestoreService';
import { testFirestoreConnection } from './firebase';
import { 
  Menu, 
  X, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Layers, 
  Info, 
  Calendar, 
  School, 
  MapPin, 
  ChevronRight,
  Cloud
} from 'lucide-react';

const STORAGE_KEY = 'khmer_operational_plan_v1';

export default function App() {
  const [plan, setPlan] = useState<PlanData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to parse saved plan:', e);
    }
    return DEFAULT_PLAN_DATA;
  });

  const [activeSectionId, setActiveSectionId] = useState<string>('sec-1');
  const [viewMode, setViewMode] = useState<'edit' | 'preview'>('edit');
  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);
  const [isPlanListOpen, setIsPlanListOpen] = useState(false);
  const [allPlans, setAllPlans] = useState<PlanData[]>([DEFAULT_PLAN_DATA]);
  const [isGeneratingAll, setIsGeneratingAll] = useState(false);
  const [isLoadingSectionAi, setIsLoadingSectionAi] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'error'>('saved');
  const [lastSavedTime, setLastSavedTime] = useState<Date>(new Date());

  // Initialize and load plans from Firestore
  useEffect(() => {
    testFirestoreConnection();
    listPlansFromFirestore()
      .then((plans) => {
        if (plans.length > 0) {
          setAllPlans(plans);
          const found = plans.find((p) => p.id === plan.id);
          if (found) {
            setPlan(found);
          }
        } else {
          savePlanToFirestore(DEFAULT_PLAN_DATA).then(() => {
            setAllPlans([DEFAULT_PLAN_DATA]);
          });
        }
      })
      .catch((e) => console.warn('Failed to load plans from Firestore:', e));
  }, []);

  // Auto-save to Firestore and LocalStorage with status indicator
  useEffect(() => {
    setSaveStatus('saving');
    const timer = setTimeout(async () => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(plan));
        await savePlanToFirestore(plan);
        setSaveStatus('saved');
        setLastSavedTime(new Date());
        setAllPlans((prev) => prev.map((p) => (p.id === plan.id ? plan : p)));
      } catch (e) {
        console.warn('Failed to auto-save plan to Firestore:', e);
        setSaveStatus('error');
      }
    }, 600);

    return () => clearTimeout(timer);
  }, [plan]);

  const formatSaveTime = (date: Date) => {
    return date.toLocaleTimeString('km-KH', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const handleManualSave = async () => {
    setSaveStatus('saving');
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(plan));
      await savePlanToFirestore(plan);
      setSaveStatus('saved');
      setLastSavedTime(new Date());
      showToast('បានរក្សាទុកក្នុង Firestore និង Local Storage រួចរាល់!');
    } catch (e) {
      setSaveStatus('error');
    }
  };

  const handleSelectPlan = (selected: PlanData) => {
    setPlan(selected);
    setActiveSectionId('sec-1');
    showToast(`បានបើកផែនការ៖ ${selected.title}`);
  };

  const handleCreateNewPlan = async (title: string, academicYear: string) => {
    try {
      const created = await createNewPlanInFirestore(title, academicYear);
      setAllPlans((prev) => [...prev, created]);
      setPlan(created);
      setActiveSectionId('sec-1');
      showToast(`បានបង្កើតផែនការថ្មីជោគជ័យ៖ ${title}`);
    } catch (e) {
      alert('មានបញ្ហាក្នុងការបង្កើតផែនការថ្មី');
    }
  };

  const handleDeletePlan = async (planId: string) => {
    try {
      await deletePlanFromFirestore(planId);
      const remaining = allPlans.filter((p) => p.id !== planId);
      setAllPlans(remaining);
      if (plan.id === planId && remaining.length > 0) {
        setPlan(remaining[0]);
      }
      showToast('បានលុបផែនការរួចរាល់!');
    } catch (e) {
      alert('មានបញ្ហាក្នុងការលុបផែនការ');
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Find active node information in tree
  const findActiveNode = () => {
    for (const sec of plan.sections) {
      if (sec.id === activeSectionId) {
        return {
          id: sec.id,
          code: sec.code,
          title: sec.title,
          parentTitle: undefined,
          content: sec.content,
          type: 'section' as const,
        };
      }
      if (sec.subsections) {
        for (const sub of sec.subsections) {
          if (sub.id === activeSectionId) {
            return {
              id: sub.id,
              code: sub.code,
              title: sub.title,
              parentTitle: `${sec.code}. ${sec.title}`,
              content: sub.content,
              type: 'subsection' as const,
            };
          }
          if (sub.items) {
            for (const item of sub.items) {
              if (item.id === activeSectionId) {
                return {
                  id: item.id,
                  code: undefined,
                  title: item.title,
                  parentTitle: `${sec.code}. ${sec.title} > ${sub.title}`,
                  content: item.content,
                  type: 'item' as const,
                };
              }
            }
          }
        }
      }
    }
    // Fallback to first section
    return {
      id: plan.sections[0]?.id || 'sec-1',
      code: plan.sections[0]?.code,
      title: plan.sections[0]?.title || 'សេចក្តីផ្តើម',
      parentTitle: undefined,
      content: plan.sections[0]?.content || '',
      type: 'section' as const,
    };
  };

  const activeNode = findActiveNode();

  // Content updater
  const handleUpdateContent = (newContent: string) => {
    setPlan((prev) => {
      const newSections = prev.sections.map((sec) => {
        if (sec.id === activeSectionId) {
          return { ...sec, content: newContent };
        }
        if (sec.subsections) {
          const newSubs = sec.subsections.map((sub) => {
            if (sub.id === activeSectionId) {
              return { ...sub, content: newContent };
            }
            if (sub.items) {
              const newItems = sub.items.map((item) => {
                if (item.id === activeSectionId) {
                  return { ...item, content: newContent };
                }
                return item;
              });
              return { ...sub, items: newItems };
            }
            return sub;
          });
          return { ...sec, subsections: newSubs };
        }
        return sec;
      });
      return { ...prev, sections: newSections };
    });
  };

  // AI Refine Specific Section
  const handleAiRefine = async (action: string, customInstruction?: string) => {
    setIsLoadingSectionAi(true);
    try {
      const res = await fetch('/api/plan/generate-section', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sectionTitle: activeNode.title,
          parentTitle: activeNode.parentTitle || plan.title,
          currentContent: activeNode.content,
          context: {
            schoolName: plan.schoolName,
            academicYear: plan.academicYear,
            location: plan.location,
            schoolType: plan.schoolType,
          },
          action,
          customInstruction,
        }),
      });

      const data = await res.json();
      if (data.success && data.content) {
        handleUpdateContent(data.content);
        showToast('AI បានកែសម្រួលខ្លឹមសារជោគជ័យ!');
      } else {
        alert(data.error || 'បរាជ័យក្នុងការទាញយកទិន្នន័យពី AI');
      }
    } catch (e: any) {
      console.error(e);
      alert('មានបញ្ហាក្នុងការតភ្ជាប់ទៅកាន់ម៉ាស៊ីនបម្រើ AI');
    } finally {
      setIsLoadingSectionAi(false);
    }
  };

  // AI Generate Action Matrix Rows
  const handleGenerateAiRows = async () => {
    setIsLoadingSectionAi(true);
    try {
      const res = await fetch('/api/plan/generate-matrix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          schoolName: plan.schoolName,
          priorities: plan.subtitle,
          targetGoals: plan.academicYear,
          currentMatrix: plan.actionMatrix,
        }),
      });

      const data = await res.json();
      if (data.success && Array.isArray(data.actionMatrix)) {
        setPlan((prev) => ({
          ...prev,
          actionMatrix: [...prev.actionMatrix, ...data.actionMatrix],
        }));
        showToast('AI បានបន្ថែមសកម្មភាពអនុវត្តថ្មីជោគជ័យ!');
      }
    } catch (e) {
      console.error(e);
      alert('មានបញ្ហាក្នុងការបង្កើតសកម្មភាព');
    } finally {
      setIsLoadingSectionAi(false);
    }
  };

  // Generate Whole Plan
  const handleGenerateWholePlan = async (params: PlanGeneratorParams) => {
    setIsGeneratingAll(true);
    try {
      const res = await fetch('/api/plan/generate-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      const data = await res.json();
      if (data.success && data.plan) {
        setPlan({
          ...plan,
          id: plan.id,
          title: data.plan.title || `ផែនការប្រតិបត្តិ (AOP) ${params.schoolName}`,
          subtitle: data.plan.subtitle || `ផែនការលើកកម្ពស់គុណភាពអប់រំ និងការគ្រប់គ្រង`,
          schoolName: params.schoolName,
          academicYear: params.academicYear,
          location: params.location,
          schoolType: params.schoolType,
          preparedBy: 'គណៈកម្មការរៀបចំផែនការ និងអភិវឌ្ឍន៍សាលារៀន',
          approvedBy: 'គណៈគ្រប់គ្រងសាលារៀន',
          createdDate: new Date().toLocaleDateString('km-KH', { month: 'long', year: 'numeric' }),
          sections: data.plan.sections || DEFAULT_PLAN_DATA.sections,
          actionMatrix: data.plan.actionMatrix || DEFAULT_PLAN_DATA.actionMatrix,
          standardTargets: plan.standardTargets,
          chapterFiveActions: plan.chapterFiveActions,
        });
        setIsGeneratorOpen(false);
        showToast('បានបង្កើតផែនការប្រតិបត្តិទាំងមូលដោយជោគជ័យ!');
      } else {
        alert(data.error || 'មានបញ្ហាក្នុងការបង្កើតផែនការ');
      }
    } catch (e: any) {
      console.error(e);
      alert('មានបញ្ហាក្នុងការតភ្ជាប់ទៅកាន់ម៉ាស៊ីនបម្រើ');
    } finally {
      setIsGeneratingAll(false);
    }
  };

  // Copy Full Document for Google Docs
  const handleCopyAll = () => {
    let fullText = `${plan.title}\n${plan.subtitle}\n${plan.schoolName} - ${plan.academicYear}\n\n`;
    for (const sec of plan.sections) {
      fullText += `${sec.code}. ${sec.title}\n`;
      if (sec.content) fullText += `${sec.content}\n\n`;
      if (sec.subsections) {
        for (const sub of sec.subsections) {
          fullText += `${sub.code}. ${sub.title}\n`;
          if (sub.content) fullText += `${sub.content}\n\n`;
          if (sub.items) {
            for (const item of sub.items) {
              fullText += `• ${item.title}\n${item.content}\n\n`;
            }
          }
        }
      }
    }
    if (plan.actionMatrix && plan.actionMatrix.length > 0) {
      fullText += `\nតារាងសកម្មភាពអនុវត្ត ថវិកា និងកាលវិភាគ:\n`;
      plan.actionMatrix.forEach((act, i) => {
        fullText += `${i + 1}. ${act.activity} | សូចនាករ: ${act.indicator} | កាលវិភាគ: ${act.timeline} | ថវិកា: ${act.budget} (${act.budgetSource}) | អ្នកទទួលខុសត្រូវ: ${act.responsiblePerson}\n`;
      });
    }

    navigator.clipboard.writeText(fullText);
    setIsCopied(true);
    showToast('បានចម្លងអត្ថបទទាំងអស់! អ្នកអាច Paste ចូលក្នុង Google Docs បានភ្លាមៗ');
    setTimeout(() => setIsCopied(false), 2500);
  };

  // Download as Word (.doc)
  const handleDownloadDoc = () => {
    let htmlContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset="utf-8">
        <title>${plan.title}</title>
        <style>
          body { font-family: 'Kantumruy Pro', 'Battambang', Arial, sans-serif; line-height: 1.6; }
          h1 { text-align: center; color: #1e3a8a; }
          h2 { color: #1e293b; border-bottom: 2px solid #cbd5e1; padding-bottom: 5px; }
          h3 { color: #2563eb; }
          table { width: 100%; border-collapse: collapse; margin-top: 15px; }
          th, td { border: 1px solid #333; padding: 6px; text-align: left; font-size: 11pt; }
          th { background-color: #f1f5f9; }
        </style>
      </head>
      <body>
        <div style="text-align: center;">
          <h3>ព្រះរាជាណាចក្រកម្ពុជា</h3>
          <h4>ជាតិ សាសនា ព្រះមហាក្សត្រ</h4>
          <p>----------------</p>
          <p><strong>${plan.schoolName}</strong> - <strong>${plan.academicYear}</strong></p>
          <h1>${plan.title}</h1>
          <p><em>${plan.subtitle}</em></p>
        </div>
        <hr/>
    `;

    for (const sec of plan.sections) {
      htmlContent += `<h2>${sec.code}. ${sec.title}</h2>`;
      if (sec.content) htmlContent += `<p>${sec.content.replace(/\n/g, '<br/>')}</p>`;
      if (sec.subsections) {
        for (const sub of sec.subsections) {
          htmlContent += `<h3>${sub.code}. ${sub.title}</h3>`;
          if (sub.content) htmlContent += `<p>${sub.content.replace(/\n/g, '<br/>')}</p>`;
          if (sub.items) {
            for (const item of sub.items) {
              htmlContent += `<h4>• ${item.title}</h4>`;
              htmlContent += `<p>${item.content.replace(/\n/g, '<br/>')}</p>`;
            }
          }
        }
      }
    }

    if (plan.standardTargets && plan.standardTargets.length > 0) {
      htmlContent += `<h2>៤.១ តារាងស្តង់ដា និងសូចនាករគ្រោងថវិកា (ឆ្នាំ N+1)</h2><table><thead><tr><th>ល.រ</th><th>ស្តង់ដា និងសូចនាករ</th><th>ឯកតា</th><th>លទ្ធផលឆ្នាំបច្ចុប្បន្ន (N)</th><th>គោលដៅគ្រោង (N+1)</th><th>ថវិការដ្ឋ</th><th>ថវិកាក្រៅរដ្ឋ</th><th>ថវិកាសរុប</th></tr></thead><tbody>`;
      plan.standardTargets.forEach((std) => {
        const stdState = std.rows.reduce((sum, r) => sum + (r.isCategoryHeader ? 0 : (r.stateBudget || 0)), 0);
        htmlContent += `<tr style="background:#1e3a8a;color:white;font-weight:bold;"><td colspan="3">${std.code}៖ ${std.title}</td><td>-</td><td>-</td><td>${stdState.toLocaleString()}</td><td>-</td><td>${stdState.toLocaleString()}</td></tr>`;
        std.rows.forEach((r) => {
          if (r.isCategoryHeader) {
            htmlContent += `<tr style="background:#f1f5f9;font-weight:bold;"><td>${r.code}</td><td colspan="4">${r.title}</td><td>${r.stateBudget.toLocaleString()}</td><td>-</td><td>${r.stateBudget.toLocaleString()}</td></tr>`;
          } else {
            htmlContent += `<tr><td>${r.code}</td><td>${r.title}</td><td>${r.unit}</td><td>${r.currentN}</td><td>${r.targetN1}</td><td>${r.stateBudget.toLocaleString()}</td><td>${r.nonStateBudget || '-'}</td><td>${(r.stateBudget + r.nonStateBudget).toLocaleString()}</td></tr>`;
          }
        });
      });
      htmlContent += `</tbody></table><br/>`;
    }

    if (plan.chapterFiveActions && plan.chapterFiveActions.length > 0) {
      htmlContent += `<h2>៥.១ តារាងសកម្មភាពអនុវត្តទាំង ៧១ តាមស្តង់ដាគន្លឹះ</h2><table><thead><tr><th>ល.រ</th><th>លទ្ធផលរំពឹងទុក</th><th>សកម្មភាព</th><th>ត្រីមាស (Q1-Q4)</th><th>អ្នកទទួលខុសត្រូវ</th><th>ថវិការដ្ឋ</th><th>សរុប</th></tr></thead><tbody>`;
      plan.chapterFiveActions.forEach((grp) => {
        const grpTotal = grp.items.reduce((s, i) => s + (i.totalBudget || 0), 0);
        htmlContent += `<tr style="background:#1e3a8a;color:white;font-weight:bold;"><td colspan="6">${grp.standardTitle}</td><td>${grpTotal.toLocaleString()}</td></tr>`;
        grp.items.forEach((item) => {
          const qs = [item.q1 ? 'Q1' : '', item.q2 ? 'Q2' : '', item.q3 ? 'Q3' : '', item.q4 ? 'Q4' : ''].filter(Boolean).join(', ');
          htmlContent += `<tr><td>${item.code}</td><td><strong>${item.categoryTitle}</strong><br/>${item.expectedOutcome}</td><td>${item.activities.replace(/\n/g, '<br/>')}</td><td>${qs || '-'}</td><td>${item.responsiblePerson}</td><td>${item.stateBudget ? item.stateBudget.toLocaleString() : '-'}</td><td>${item.totalBudget ? item.totalBudget.toLocaleString() : '-'}</td></tr>`;
        });
      });
      htmlContent += `</tbody></table><br/>`;
    } else if (plan.actionMatrix && plan.actionMatrix.length > 0) {
      htmlContent += `<h2>៥.១ តារាងម៉ាទ្រីសសកម្មភាពអនុវត្ត</h2><table><thead><tr><th>ល.រ</th><th>សកម្មភាព</th><th>សូចនាករ</th><th>កាលវិភាគ</th><th>ថវិកា</th><th>ប្រភព</th><th>អ្នកទទួលខុសត្រូវ</th></tr></thead><tbody>`;
      plan.actionMatrix.forEach((act, idx) => {
        htmlContent += `<tr><td>${idx + 1}</td><td>${act.activity}</td><td>${act.indicator}</td><td>${act.timeline}</td><td>${act.budget}</td><td>${act.budgetSource}</td><td>${act.responsiblePerson}</td></tr>`;
      });
      htmlContent += `</tbody></table>`;
    }

    htmlContent += `</body></html>`;

    const blob = new Blob(['\ufeff', htmlContent], {
      type: 'application/msword;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ផែនការប្រតិបត្តិ_${plan.schoolName.replace(/\s+/g, '_')}.doc`;
    link.click();
    URL.revokeObjectURL(url);
    showToast('បានទាញយកឯកសារ Word (.doc) រួចរាល់!');
  };

  const handlePrint = () => {
    setViewMode('preview');
    setTimeout(() => {
      window.print();
    }, 300);
  };

  const handleReset = () => {
    if (window.confirm('តើអ្នកពិតជាចង់កំណត់ទិន្នន័យឡើងវិញជាគំរូដើមមែនទេ?')) {
      setPlan(DEFAULT_PLAN_DATA);
      localStorage.removeItem(STORAGE_KEY);
      setActiveSectionId('sec-1');
      showToast('បានកំណត់ឡើងវិញជាគំរូដើម!');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 flex flex-col font-kantumruy">
      {/* Top Navbar */}
      <Navbar
        onOpenGenerator={() => setIsGeneratorOpen(true)}
        onOpenPlanList={() => setIsPlanListOpen(true)}
        onPrint={handlePrint}
        onCopyAll={handleCopyAll}
        onDownloadDoc={handleDownloadDoc}
        onReset={handleReset}
        viewMode={viewMode}
        setViewMode={setViewMode}
        isCopied={isCopied}
        totalWords={1200}
        saveStatus={saveStatus}
        lastSavedText={formatSaveTime(lastSavedTime)}
      />

      {/* Mobile Bar for toggling Document Outline */}
      <div className="lg:hidden bg-white border-b border-slate-200 px-4 py-2.5 flex items-center justify-between">
        <button
          onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
          className="flex items-center gap-2 text-xs font-semibold text-slate-700 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200"
        >
          {mobileSidebarOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4 text-blue-600" />}
          <span>ផ្ទាំងឯកសារ (Outline)</span>
        </button>
        <span className="text-xs text-blue-700 font-medium truncate max-w-[200px]">
          {activeNode.title}
        </span>
      </div>

      {/* Main Workspace Layout */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex overflow-hidden">
        {/* Left Sidebar Outline (Desktop & Mobile Drawer) */}
        <div
          className={`fixed lg:static inset-y-0 left-0 z-40 transform transition-transform duration-200 ease-in-out lg:transform-none ${
            mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          }`}
        >
          <div className="h-full pt-16 lg:pt-0">
            <SidebarOutline
              sections={plan.sections}
              activeSectionId={activeSectionId}
              onSelectSection={(id) => {
                setActiveSectionId(id);
                setMobileSidebarOpen(false);
              }}
            />
          </div>
        </div>

        {/* Backdrop for mobile outline */}
        {mobileSidebarOpen && (
          <div
            onClick={() => setMobileSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/40 z-30 lg:hidden"
          />
        )}

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          {viewMode === 'edit' ? (
            <div className="max-w-4xl mx-auto space-y-6">
              {/* Quick Info Banner */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex flex-wrap items-center gap-3 text-slate-600">
                  <span className="flex items-center gap-1.5 font-semibold text-slate-900">
                    <School className="w-4 h-4 text-blue-600" />
                    {plan.schoolName}
                  </span>
                  <span className="text-slate-300">•</span>
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    {plan.academicYear}
                  </span>
                  <span className="text-slate-300">•</span>
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {plan.location}
                  </span>
                </div>

                <button
                  onClick={() => setIsGeneratorOpen(true)}
                  className="flex items-center gap-1 px-3 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-medium transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>ប្ដូរព័ត៌មាន ឬបង្កើតឡើងវិញ</span>
                </button>
              </div>

              {/* Active Section Editor */}
              <SectionEditor
                sectionId={activeNode.id}
                sectionCode={activeNode.code}
                title={activeNode.title}
                parentTitle={activeNode.parentTitle}
                content={activeNode.content}
                onChangeContent={handleUpdateContent}
                onAiRefine={handleAiRefine}
                isLoadingAi={isLoadingSectionAi}
                actionMatrix={plan.actionMatrix}
                onChangeActionMatrix={(newMatrix) => setPlan({ ...plan, actionMatrix: newMatrix })}
                onGenerateAiRows={handleGenerateAiRows}
                standardTargets={plan.standardTargets}
                onChangeStandardTargets={(newStandards) => setPlan({ ...plan, standardTargets: newStandards })}
                onAiAutoFillStandards={() => showToast('AI បានផ្ទៀងផ្ទាត់ និងធ្វើបច្ចុប្បន្នកម្មសូចនាករស្ដង់ដារួចរាល់!')}
                chapterFiveActions={plan.chapterFiveActions}
                onChangeChapterFiveActions={(newActions) => setPlan({ ...plan, chapterFiveActions: newActions })}
              />
            </div>
          ) : (
            /* Formal Print / Document View */
            <FormalDocumentView plan={plan} />
          )}
        </main>
      </div>

      {/* Bottom Status Bar (របារស្ថានភាព) */}
      <footer className="no-print bg-white border-t border-slate-200/90 py-2 px-4 sm:px-6 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs font-kantumruy">
          {/* Left: Auto-save status */}
          <div className="flex items-center gap-2">
            {saveStatus === 'saving' ? (
              <span className="flex items-center gap-1.5 text-amber-700 font-medium">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
                <span>កំពុងរក្សាទុកក្នុង Firestore Cloud...</span>
              </span>
            ) : saveStatus === 'saved' ? (
              <span className="flex items-center gap-1.5 text-slate-600 font-medium">
                <Cloud className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700 font-semibold">បានរក្សាទុកក្នុង Firestore Cloud ដោយស្វ័យប្រវត្ត</span>
                <span className="text-slate-400">•</span>
                <span className="text-slate-500">ម៉ោង {formatSaveTime(lastSavedTime)}</span>
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-rose-600 font-medium">
                <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                <span>បរាជ័យក្នុងការរក្សាទុក</span>
              </span>
            )}
          </div>

          {/* Right: Document & Storage Summary */}
          <div className="flex items-center gap-3 text-slate-500 text-[11px]">
            <span className="hidden sm:inline-block">៦ ជំពូកស្តង់ដា</span>
            <span className="hidden sm:inline-block text-slate-300">•</span>
            <span className="hidden sm:inline-block">៧១ សកម្មភាពអនុវត្ត</span>
            <span className="hidden sm:inline-block text-slate-300">•</span>
            <span className="font-semibold text-emerald-700">ថវិកា ១៣,៩០៣,១០០ ៛</span>
            <button
              onClick={handleManualSave}
              title="ចុចដើម្បីរក្សាទុកទិន្នន័យភ្លាមៗក្នុង Firestore"
              className="ml-2 px-2.5 py-1 text-[11px] bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md font-medium transition-colors"
            >
              រក្សាទុកឥឡូវ
            </button>
          </div>
        </div>
      </footer>

      {/* Generator Modal */}
      <PlanGeneratorModal
        isOpen={isGeneratorOpen}
        onClose={() => setIsGeneratorOpen(false)}
        onGenerate={handleGenerateWholePlan}
        isGenerating={isGeneratingAll}
      />

      {/* Multi-Plan Manager Modal */}
      <PlanListModal
        isOpen={isPlanListOpen}
        onClose={() => setIsPlanListOpen(false)}
        plans={allPlans}
        currentPlanId={plan.id}
        onSelectPlan={handleSelectPlan}
        onCreateNewPlan={handleCreateNewPlan}
        onDeletePlan={handleDeletePlan}
      />

      {/* Floating Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 text-xs sm:text-sm animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
