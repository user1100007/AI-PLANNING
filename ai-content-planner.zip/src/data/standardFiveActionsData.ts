export interface ChapterFiveActionItem {
  id: string;
  code: string; // e.g. "១.១", "១.២"
  standardCode: string; // "ស្តង់ដាទី១", "ស្តង់ដាទី២", etc.
  categoryTitle: string; // e.g. "១. ការប្រមូលកុមារចូលរៀន"
  expectedOutcome: string; // លទ្ធផលរំពឹងទុក
  activities: string; // សកម្មភាពអនុវត្ត (bullet points)
  q1: boolean;
  q2: boolean;
  q3: boolean;
  q4: boolean;
  responsiblePerson: string;
  stateBudget: number;
  communityBudget: number;
  partnerBudget: number;
  totalBudget: number;
}

export interface ChapterFiveStandardGroup {
  id: string;
  standardTitle: string;
  items: ChapterFiveActionItem[];
}

export const DEFAULT_CHAPTER_FIVE_ACTIONS: ChapterFiveStandardGroup[] = [
  {
    id: 'c5-std-1',
    standardTitle: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    items: [
      {
        id: 'c5-1-1',
        code: '១.១',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '១. ការប្រមូលកុមារចូលរៀន',
        expectedOutcome: 'ភាគរយសិស្សថ្នាក់ទី១ចូលរៀនបានត្រឹមត្រូវតាមអាយុ ១០០%',
        activities: '• រៀបចំ ការចុះបញ្ជីសិស្សថ្មី\n• ផ្សព្វផ្សាយអំពី អត្ថប្រយោជន៍នៃការចូលរៀន តាមសហគមន៍\n• សហការជាមួយ មាតាបិតា និងអាជ្ញាធរ ដើម្បីធានាថាកុមារទាំងអស់ចូលរៀនតាមអាយុ',
        q1: false, q2: false, q3: false, q4: true,
        responsiblePerson: 'គណៈគ្រប់គ្រង និងគ្រូថ្នាក់ទី១',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-1-2',
        code: '២.១',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '២. សិស្សរៀនបានគង់វង្សក្នុងសាលារៀន',
        expectedOutcome: 'ភាគរយសិស្សបោះបង់ការសិក្សាបានថយចុះមកត្រឹម ៣%',
        activities: '• ធ្វើ សម្ភាសន៍សិស្ស និងមាតាបិតា ដើម្បីរកមូលហេតុបោះបង់\n• ផ្តល់ជំនួយ សម្ភារៈសិក្សា ឬអាហារូបករណ៍\n• បង្កើត ក្រុមគាំទ្រសិស្សក្នុងសាលា ដើម្បីជួយពង្រឹងចិត្តស្មោះត្រង់ក្នុងការរៀន',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គណៈកម្មការទ្រទ្រង់សាលា និងគ្រូបន្ទុកថ្នាក់',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-1-3',
        code: '២.២',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '២. សិស្សរៀនបានគង់វង្សក្នុងសាលារៀន',
        expectedOutcome: 'ភាគរយសិស្សរៀនត្រួតថ្នាក់បានថយចុះមកត្រឹម ២%',
        activities: '• រៀបចំ ថ្នាក់បង្រៀនបន្ថែម (Remedial Class) សម្រាប់សិស្សដែលមានលទ្ធផលទាប\n• តាមដាន លទ្ធផលសិក្សា និងពិន្ទុ ជាប្រចាំ\n• ប្រើ វិធីសាស្រ្តបង្រៀនចម្រុះ ដើម្បីឱ្យសិស្សយល់បានងាយ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបង្រៀនគ្រប់ថ្នាក់',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-1-4',
        code: '៣.១',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '៣. លទ្ធផលសិក្សារបស់សិស្ស',
        expectedOutcome: 'ភាគរយសិស្សមាននិទ្ទេស A B និង C មុខវិជ្ជាភាសាខ្មែរ មានការកើនឡើង',
        activities: '• ពង្រឹងការបង្រៀនលើការសរសេរអត្ថបទ (រៀបរាប់ ពិពណ៌នា និងរបាយការណ៍) វេយ្យាករណ៍ និងការអានយល់ន័យស៊ីជម្រៅ\n• រៀបចំថ្នាក់បង្រៀនបំប៉ន (Remedial Teaching) ដល់សិស្សទទួលបាននិទ្ទេស D និង E និងផ្តល់លំហាត់ប្រឈមបន្ថែម (Advanced Tasks) សម្រាប់រក្សាការពារនិទ្ទេស A B C',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'ក្រុមបច្ចេកទេសភាសាខ្មែរ',
        stateBudget: 450000, communityBudget: 0, partnerBudget: 0, totalBudget: 450000
      },
      {
        id: 'c5-1-5',
        code: '៣.២',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '៣. លទ្ធផលសិក្សារបស់សិស្ស',
        expectedOutcome: 'ភាគរយសិស្សមាននិទ្ទេស A B និង C មុខវិជ្ជាគណិតវិទ្យា មានការកើនឡើង',
        activities: '• ពង្រឹងការបង្រៀនគំនិតវិភាគ ការដោះស្រាយលំហាត់ស្មុគស្មាញ និងការអនុវត្តរូបមន្តជាក់ស្តែងតាមរយៈការប្រើប្រាស់សម្ភារឧបទេស\n• បង្កើតក្រុមសិក្សារួមគ្នា (Peer Tutoring) និងរៀបចំម៉ោងដោះស្រាយលំហាត់កម្រិតខ្ពស់សម្រាប់សិស្សពូកែ ព្រមទាំងជួយសង្គ្រោះសិស្សខ្សោយ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'ក្រុមបច្ចេកទេសគណិតវិទ្យា',
        stateBudget: 450000, communityBudget: 0, partnerBudget: 0, totalBudget: 450000
      },
      {
        id: 'c5-1-6',
        code: '៣.៣',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '៣. លទ្ធផលសិក្សារបស់សិស្ស',
        expectedOutcome: 'ភាគរយសិស្សថ្នាក់ទី៣ មានសមត្ថភាពអានតាមស្តង់ដា (៤៥ ទៅ ៦០ពាក្យក្នុង១នាទី) មានការកើនឡើង',
        activities: '• អនុវត្តវិធីសាស្ត្រអំណានថ្នាក់ដំបូង ដោយផ្តោតលើការផ្សំសំឡេង (ព្យញ្ជនៈ ស្រៈ ជើងពាក្យ និងសញ្ញា) និងការអានអត្ថបទខ្លីៗដដែលៗ (Repeated Reading)\n• ប្រើប្រាស់បណ្ណអក្សរ (Flashcards) និងសកម្មភាពល្បែងអានអក្សរក្នុងថ្នាក់រៀនដើម្បីជំរុញចំណាប់អារម្មណ៍សិស្ស',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបង្រៀនថ្នាក់ទី ៣',
        stateBudget: 270000, communityBudget: 0, partnerBudget: 0, totalBudget: 270000
      },
      {
        id: 'c5-1-7',
        code: '៣.៤',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '៣. លទ្ធផលសិក្សារបស់សិស្ស',
        expectedOutcome: 'ភាគរយសិស្សថ្នាក់ទី៦ មានសមត្ថភាពអានតាមស្តង់ដា (១០០ ទៅ ១២០ពាក្យក្នុង១នាទី) មានការកើនឡើង',
        activities: '• ជំរុញទម្លាប់អានសៀវភៅបណ្ណាល័យ រឿងខ្លី ឬអត្ថបទផ្សេងៗ និងបង្រៀនបច្ចេកទេសអានចាប់យកអត្ថន័យលឿន (Skimming and Scanning)\n• រៀបចំការប្រកួតប្រជែងអានល្បឿន និងការយល់ន័យក្នុងកម្រិតថ្នាក់រៀន ឬកម្រិតសាលារៀន',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបង្រៀនថ្នាក់ទី ៦',
        stateBudget: 250000, communityBudget: 0, partnerBudget: 0, totalBudget: 250000
      },
      {
        id: 'c5-1-8',
        code: '៤.១',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '៤. ស្ថានភាពអាហារូបត្ថម្ភ (ការគាំទ្រផ្នែកសុខភាពនិងសុវត្ថិភាពសិក្សា)',
        expectedOutcome: 'ភាគរយសិស្សមានស្ថានភាពអាហារូបត្ថម្ភធម្មតា',
        activities: '• សហការជាមួយមណ្ឌលសុខភាព ឬអង្គការដៃគូដើម្បីពិនិត្យសុខភាព និងវាស់កម្ពស់-ទម្ងន់សិស្សជាប្រចាំ\n• រៀបចំកម្មវិធីអប់រំសុខភាព និងអាហារូបត្ថម្ភដល់សិស្ស និងមាតាបិតា ព្រមទាំងត្រួតពិនិត្យ និងហាមឃាត់ការលក់ចំណីអាហារគ្មានគុណភាព ឬខូចគុណភាពនៅក្បែរ និងក្នុងបរិវេណសាលារៀន',
        q1: true, q2: false, q3: true, q4: false,
        responsiblePerson: 'គ្រូទទួលបន្ទុកសុខភាពសិក្សា',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-1-9',
        code: '៤.២',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '៤. ស្ថានភាពអាហារូបត្ថម្ភ (ការគាំទ្រផ្នែកសុខភាពនិងសុវត្ថិភាពសិក្សា)',
        expectedOutcome: 'ភាគរយសិស្សដែលមានបញ្ហាអាហារូបត្ថម្ភ ទទួលបានកិច្ចអន្តរាគមន៍',
        activities: '• បង្កើតបញ្ជីឈ្មោះសិស្សដែលមានបញ្ហាអាហារូបត្ថម្ភ (ក្រិន ស្គមស្គាំង ឬធាត់ជ្រុល) និងផ្តល់អាហារបំប៉ន ព្រមទាំងបញ្ជូនករណីធ្ងន់ធ្ងរទៅមណ្ឌលសុខភាព\n• ណែនាំដល់អាណាព្យាបាលអំពីរបបអាហារដែលមានជីវជាតិគ្រប់គ្រាន់សម្រាប់កុមារ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គណៈកម្មការសុខភាពសាលា',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-1-10',
        code: '៤.៣',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '៤. ស្ថានភាពអាហារូបត្ថម្ភ (ការគាំទ្រផ្នែកសុខភាពនិងសុវត្ថិភាពសិក្សា)',
        expectedOutcome: 'ភាគរយសិស្សក្រីក្រទទួលបានអាហារូបករណ៍ ឬការឧបត្ថម្ភនានា',
        activities: '• បង្កើតគណៈកម្មការពិនិត្យ និងជ្រើសរើសសិស្សក្រីក្រ ឬងាយរងគ្រោះតាមលក្ខខណ្ឌវិនិច្ឆ័យច្បាស់លាស់ និងត្រឹមត្រូវ\n• រៀបចំកៀរគររកសប្បុរសជន ឬសហការជាមួយក្រសួង-ស្ថាប័ន និងអង្គការដៃគូដើម្បីផ្តល់ថវិកាឧបត្ថម្ភ សម្ភារសិក្សា ឬអង្ករដល់គ្រួសារសិស្សក្រីក្រ',
        q1: true, q2: false, q3: true, q4: false,
        responsiblePerson: 'គ.គ.ស និងគណៈគ្រប់គ្រង',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-1-11',
        code: '៥.១',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '៥. សីលធម៌ និងឥរិយាបថរបស់សិស្ស',
        expectedOutcome: 'ភាគរយកុមារទទួលបានការប្រឹក្សាយោបល់',
        activities: '• បង្កើតបន្ទប់ប្រឹក្សាយោបល់ ឬចាត់តាំងគ្រូបន្ទុកបន្ទប់ និងគ្រូប្រឹក្សាសុខភាពផ្លូវចិត្ត ដើម្បីផ្តល់ការណែនាំដល់សិស្សដែលមានបញ្ហាអាកប្បកិរិយា បញ្ហាគ្រួសារ ឬបញ្ហាស្ត្រេស\n• អនុវត្តកម្មវិធីអប់រំសីលធម៌ និងការលើកទឹកចិត្តតាមរយៈការប្រជុំគោរពទង់ជាតិ ឬម៉ោងសីលធម៌',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូប្រឹក្សា និងគ្រូបន្ទុកថ្នាក់',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-1-12',
        code: '៥.២',
        standardCode: 'ស្តង់ដាទី១',
        categoryTitle: '៥. សីលធម៌ និងឥរិយាបថរបស់សិស្ស',
        expectedOutcome: 'ភាគរយថ្នាក់រៀនដាក់ពិន្ទុ បំណិនសម្បទា និងចរិយាសម្បទាដល់សិស្សប្រចាំឆ្នាំ',
        activities: '• ជំរុញ និងណែនាំដល់គ្រូបង្រៀនគ្រប់ថ្នាក់ឱ្យយកចិត្តទុកដាក់ដាក់ពិន្ទុវាយតម្លៃលើផ្នែកចរិយាសម្បទា និងបំណិនសម្បទា ក្នុងកាតរបាយការណ៍លទ្ធផលសិក្សារបស់សិស្ស\n• ត្រួតពិនិត្យ និងវាយតម្លៃការកត់ត្រាពិន្ទុទាំងនេះដោយនាយកសាលា ឬនាយករងបច្ចេកទេស',
        q1: false, q2: true, q3: false, q4: true,
        responsiblePerson: 'នាយករងបច្ចេកទេស និងគ្រូបង្រៀន',
        stateBudget: 300000, communityBudget: 0, partnerBudget: 0, totalBudget: 300000
      },
    ],
  },
  {
    id: 'c5-std-2',
    standardTitle: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    items: [
      {
        id: 'c5-2-1',
        code: '១.១',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '១. ការអនុវត្តវិធីសាស្ត្របង្រៀនថ្មី',
        expectedOutcome: 'ភាគរយគ្រូបង្រៀនថ្នាក់ទី១ និង/ឬ ទី២ និង/ឬ ទី៣ អនុវត្តកញ្ចប់សម្ភារៈអំណាន ថ្នាក់ដំបូងកម្រិត២ និងកម្រិត៣',
        activities: '• រៀបចំកិច្ចប្រជុំបណ្តុះបណ្តាលផ្ទៃក្នុងសាលា (School-based Training) អំពីរបៀបប្រើប្រាស់កញ្ចប់សម្ភារៈអំណានថ្នាក់ដំបូង (សៀវភៅគោល សៀវភៅរឿង ប័ណ្ណអក្សរ និងសម្ភារឧបទេស)\n• នាយកសាលា ឬគ្រូឧទ្ទេសប្រចាំសាលា ត្រូវចុះអមថែទាំ (Mentoring) និងជួយគាំទ្រដល់គ្រូក្នុងការអនុវត្តផ្ទាល់ក្នុងថ្នាក់រៀន',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូឧទ្ទេស និងគ្រូថ្នាក់ទី ១-៣',
        stateBudget: 350000, communityBudget: 0, partnerBudget: 0, totalBudget: 350000
      },
      {
        id: 'c5-2-2',
        code: '១.២',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '១. ការអនុវត្តវិធីសាស្ត្របង្រៀនថ្មី',
        expectedOutcome: 'ភាគរយគ្រូបង្រៀនថ្នាក់ទី១ និង/ឬ ទី២ និង/ឬ ទី៣ អនុវត្តកញ្ចប់សម្ភារៈគណិតវិទ្យា ថ្នាក់ដំបូងកម្រិត២ និងកម្រិត៣',
        activities: '• ជំរុញឱ្យគ្រូប្រើប្រាស់សម្ភារឧបទេសរូបវន្ត (គ្រាប់គំនិត គ្រាប់ឡុកឡាក់ ក្តារបន្ទះ និងឧបករណ៍រាប់) ដែលមានក្នុងកញ្ចប់សម្ភារៈគណិតវិទ្យា ដើម្បីឱ្យសិស្សបានស្គាល់ចំនួន និងគណនាបែបបដិបត្តិ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបង្រៀនថ្នាក់ទី ១-៣',
        stateBudget: 350000, communityBudget: 0, partnerBudget: 0, totalBudget: 350000
      },
      {
        id: 'c5-2-3',
        code: '១.៣',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '១. ការអនុវត្តវិធីសាស្ត្របង្រៀនថ្មី',
        expectedOutcome: 'ភាគរយគ្រូបង្រៀនចូលរៀនវគ្គអភិវឌ្ឍសមត្ថភាពប្រចាំឆ្នាំ',
        activities: '• រៀបចំផែនការអភិវឌ្ឍវិជ្ជាជីវៈបន្ត (CPD) ប្រចាំឆ្នាំរបស់សាលា រួមមានការបណ្តុះបណ្តាលលើវិន័យបែបវិជ្ជមាន វិធីសាស្ត្រអំណានក្នុងបណ្ណាល័យ និងការប្រឹក្សាគរុកោសល្យ',
        q1: true, q2: false, q3: true, q4: false,
        responsiblePerson: 'គណៈគ្រប់គ្រងសាលា',
        stateBudget: 300000, communityBudget: 0, partnerBudget: 0, totalBudget: 300000
      },
      {
        id: 'c5-2-4',
        code: '១.៤',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '១. ការអនុវត្តវិធីសាស្ត្របង្រៀនថ្មី',
        expectedOutcome: 'ចំនួនកិច្ចការជាគម្រោងដែលគ្រូថ្នាក់ទី៤-៦ បានដាក់ឱ្យសិស្សអនុវត្ត ក្នុង១ឆ្នាំ',
        activities: '• ណែនាំគ្រូឱ្យរៀបចំកិច្ចការគម្រោងតូចៗ (Project-based Learning) ស្របតាមកម្មវិធីសិក្សា ដូចជាការធ្វើរបាយការណ៍ស្ដីពីបរិស្ថាន ការចងក្រងអត្ថបទរឿងខ្លី ឬគម្រោងគណិតវិទ្យាជាក់ស្តែង',
        q1: false, q2: true, q3: false, q4: true,
        responsiblePerson: 'គ្រូបង្រៀនថ្នាក់ទី ៤-៦',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-2-5',
        code: '១.៥',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '១. ការអនុវត្តវិធីសាស្ត្របង្រៀនថ្មី',
        expectedOutcome: 'ភាគរយសិស្សបានធ្វើកិច្ចការតាមផ្ទះ មេរៀនភាសាខ្មែរ គណិត និងមានការកែពីគ្រូ',
        activities: '• ដាក់កិច្ចការផ្ទះសមស្រប លើមុខវិជ្ជាភាសាខ្មែរ និងគណិតវិទ្យា និងបង្កើតវិន័យក្នុងការប្រមូលសៀវភៅមកកែតម្រូវ និងផ្តល់មតិយោបល់ (Feedback) ដល់សិស្សវិញ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបង្រៀនគ្រប់ថ្នាក់',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-2-6',
        code: '២.១',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
        expectedOutcome: 'ភាគរយថ្នាក់រៀនដែលមានបំណែងចែកកម្មវិធីសិក្សា គ្រប់មុខវិជ្ជាសិក្សាគោល',
        activities: '• ផ្តល់គំរូ និងតម្រូវឱ្យគ្រូបង្រៀនគ្រប់រូបកសាងបំណែងចែកកម្មវិធីសិក្សា (Curriculum Distribution) ឱ្យបានច្បាស់លាស់តាមសប្តាហ៍ និងត្រីមាស មុនពេលបើកបវេសនកាល',
        q1: true, q2: false, q3: false, q4: false,
        responsiblePerson: 'ប្រធានក្រុមបច្ចេកទេស',
        stateBudget: 150000, communityBudget: 0, partnerBudget: 0, totalBudget: 150000
      },
      {
        id: 'c5-2-7',
        code: '២.២',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
        expectedOutcome: 'ភាគរយគ្រូដែលបានរៀបចំកិច្ចតែងការបង្រៀនថ្មី ឬបានធ្វើបច្ចុប្បន្នកម្ម គ្រប់មេរៀន និងគ្រប់មុខវិជ្ជា',
        activities: '• ជំរុញឱ្យគ្រូរៀបចំកិច្ចតែងការបង្រៀន (Lesson Plan) ឱ្យបានទៀងទាត់មុនពេលចូលបង្រៀនក្នុងថ្នាក់ ដោយផ្អែកលើវិធីសាស្ត្របង្រៀនថ្មី',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'នាយករងបច្ចេកទេស',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-2-8',
        code: '២.៣',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
        expectedOutcome: 'ចំនួនដងថ្នាក់រៀនបិទទ្វារ (សរុបថ្នាក់ទាំងអស់គិតជាមធ្យម)',
        activities: '• ពង្រឹងអភិបាលកិច្ចសាលារៀន ត្រួតពិនិត្យវត្តមានគ្រូនិងសិស្សឱ្យបានតឹងរ៉ឹង និងទប់ស្កាត់ការបិទទ្វារសាលា',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'នាយកសាលា',
        stateBudget: 53100, communityBudget: 0, partnerBudget: 0, totalBudget: 53100
      },
      {
        id: 'c5-2-9',
        code: '២.៤',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
        expectedOutcome: 'ចំនួនថ្ងៃសាលាបិទទ្វារមិនស្របតាមប្រតិទិនសិក្សាប្រចាំឆ្នាំ',
        activities: '• ពង្រឹងអភិបាលកិច្ចសាលារៀន ត្រួតពិនិត្យវត្តមានគ្រូនិងសិស្សឱ្យបានតឹងរ៉ឹង និងទប់ស្កាត់ការបិទទ្វារសាលាខុសពីច្បាប់',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'នាយកសាលា',
        stateBudget: 80000, communityBudget: 0, partnerBudget: 0, totalBudget: 80000
      },
      {
        id: 'c5-2-10',
        code: '២.៥',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
        expectedOutcome: 'ភាគរយថ្នាក់ទី ៤-៦ បានបង្រៀនភាសាបរទេស',
        activities: '• រៀបចំកាលវិភាគសិក្សាបន្ថែមសម្រាប់មុខវិជ្ជាភាសាបរទេស (អង់គ្លេស/បារាំង) ទៅក្នុងម៉ោងសិក្សា ឬសកម្មភាពក្រៅម៉ោង',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបង្រៀនភាសាបរទេស',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-2-11',
        code: '២.៦',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
        expectedOutcome: 'ភាគរយថ្នាក់ទី ៤-៦ បានបង្រៀនមេរៀន បំណិនជីវិតមូលដ្ឋាន',
        activities: '• រៀបចំកាលវិភាគសិក្សាបន្ថែមសម្រាប់បញ្ចូលមេរៀនបំណិនជីវិត (កសិកម្ម សិប្បកម្ម អនាម័យ សុវត្ថិភាព) ទៅក្នុងម៉ោងសិក្សា ឬសកម្មភាពក្រៅម៉ោង',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបង្រៀនថ្នាក់ទី ៤-៦',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-2-12',
        code: '២.៧',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
        expectedOutcome: 'ភាគរយសិស្សអវត្តមាន លើសពី៤ដង ក្នុង១ឆ្នាំសិក្សា',
        activities: '• បង្កើតប្រព័ន្ធតាមដានវត្តមានសិស្សប្រចាំថ្ងៃដោយគ្រូបន្ទុកបន្ទប់ និងទាក់ទងទៅអាណាព្យាបាលភ្លាមៗនៅពេលសិស្សអវត្តមានខុសប្រក្រតី ដើម្បីទប់ស្កាត់ការបោះបង់ការសិក្សា',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបន្ទុកថ្នាក់',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-2-13',
        code: '៣.១',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៣. សម្ភារៈរៀននិងបង្រៀន',
        expectedOutcome: 'ភាគរយសិស្សមានសៀវភៅសិក្សាគោលតាមនិយាម',
        activities: '• ស្នើសុំការបែងចែកសៀវភៅសិក្សាគោលពីមន្ទីរ/ការិយាល័យអប់រំ និងរៀបចំការខ្ចី-ឱ្យខ្ចីសៀវភៅបណ្ណាល័យសាលា ដើម្បីបំពេញបន្ថែមដល់សិស្សដែលខ្វះខាត',
        q1: true, q2: false, q3: false, q4: false,
        responsiblePerson: 'បណ្ណារក្ស និងគណៈគ្រប់គ្រង',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-2-14',
        code: '៣.២',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៣. សម្ភារៈរៀននិងបង្រៀន',
        expectedOutcome: 'ភាគរយសិស្សថ្នាក់ទី១ និង/ឬ ទី២ និង/ឬ ទី៣ មានកញ្ចប់សម្ភារៈអំណាន និងគណិតវិទ្យា ថ្នាក់ដំបូង ដែលមាតាបិតាទិញឱ្យ',
        activities: '• ជួបប្រជុំជាមួយមាតាបិតា/អាណាព្យាបាលសិស្សនៅដើមឆ្នាំ ដើម្បីពន្យល់ពីសារៈសំខាន់នៃកញ្ចប់សម្ភារៈអំណាននិងគណិតវិទ្យាថ្នាក់ដំបូង និងណែនាំពីទីកន្លែងក្នុងការទទួលបានសម្ភារៈទាំងនោះ',
        q1: true, q2: false, q3: false, q4: false,
        responsiblePerson: 'គ្រូបង្រៀនថ្នាក់ទី ១-៣',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-2-15',
        code: '៣.៣',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៣. សម្ភារៈរៀននិងបង្រៀន',
        expectedOutcome: 'ភាគរយគ្រូបង្រៀនផលិត និងប្រើប្រាស់សម្ភារៈឧបទេសជាប្រចាំ',
        activities: '• ជំរុញ និងផ្តល់ការលើកទឹកចិត្តដល់គ្រូឱ្យច្នៃប្រឌិតសម្ភារៈឧបទេសពីវត្ថុធាតុដើមក្នុងស្រុក (ក្រដាសកាតុង គម្របដប ឈើ…) សម្រាប់យកមកប្រើប្រាស់ក្នុងការបង្រៀន',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'ប្រធានក្រុមបច្ចេកទេស',
        stateBudget: 1000000, communityBudget: 0, partnerBudget: 0, totalBudget: 1000000
      },
      {
        id: 'c5-2-16',
        code: '៣.៤',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៣. សម្ភារៈរៀននិងបង្រៀន',
        expectedOutcome: 'ភាគរយគ្រូបង្រៀនប្រើប្រាស់បច្ចេកវិទ្យាបម្រើឱ្យការរៀន និងបង្រៀន',
        activities: '• បណ្តុះបណ្តាលគ្រូឱ្យចេះប្រើប្រាស់ឧបករណ៍បច្ចេកវិទ្យា (ថេប្លេត កុំព្យូទ័រ កំពង់ផែវីដេអូអប់រំ) និងទាញយកវីដេអូបង្រៀនគំរូមកបញ្ចាំងជូនសិស្សមើលក្នុងថ្នាក់រៀន',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបច្ចេកវិទ្យា ICT',
        stateBudget: 400000, communityBudget: 0, partnerBudget: 0, totalBudget: 400000
      },
      {
        id: 'c5-2-17',
        code: '៤.១',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៤. ការជួយគាំទ្រសិស្ស',
        expectedOutcome: 'ភាគរយសិស្ស និងមាតាបិតា បានចុះកិច្ចព្រមព្រៀង រៀនសូត្រប្រចាំឆ្នាំជាមួយគ្រូ',
        activities: '• រៀបចំទម្រង់កិច្ចព្រមព្រៀងរៀនសូត្រ (Learning Agreement) ដែលចែងពីការប្តេជ្ញាចិត្តរបស់សិស្ស អាណាព្យាបាល និងគ្រូបង្រៀន រួចអញ្ជើញមាតាបិតាមកផ្ដិតមេដៃ ឬចុះហត្ថលេខារួមគ្នា',
        q1: true, q2: false, q3: false, q4: false,
        responsiblePerson: 'គ្រូបន្ទុកថ្នាក់',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
      {
        id: 'c5-2-18',
        code: '៤.២',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៤. ការជួយគាំទ្រសិស្ស',
        expectedOutcome: 'ភាគរយថ្នាក់រៀនមានការប្រជុំជាមួយ មាតាបិតា ពិនិត្យតាមដានការរៀនសូត្រ ទៀងទាត់',
        activities: '• កំណត់កាលវិភាគប្រជុំអាណាព្យាបាលសិស្សប្រចាំត្រីមាស ដើម្បីរាយការណ៍ពីវឌ្ឍនភាពសិក្សា បញ្ហាអវត្តមាន និងបញ្ហាប្រឈមផ្សេងៗ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គណៈកម្មការ គ.គ.ថ',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-2-19',
        code: '៤.៣',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៤. ការជួយគាំទ្រសិស្ស',
        expectedOutcome: 'ភាគរយសិស្សរៀនយឺតបានទទួលការជួយប្រចាំខែ ផ្អែកតាមលទ្ធផល តេស្តស្តង់ដាប្រចាំខែ',
        activities: '• វិភាគលទ្ធផលតេស្តប្រចាំខែ ដើម្បីកំណត់មុខសញ្ញាសិស្សរៀនយឺត និងរៀបចំម៉ោងបង្រៀនបំប៉នពិសេស (Remedial Teaching)',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបង្រៀនគ្រប់ថ្នាក់',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
      {
        id: 'c5-2-20',
        code: '៥.១',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៥. ដំណើរការបណ្ណាល័យ',
        expectedOutcome: 'ចំនួនសៀវភៅដែលសិស្សម្នាក់ៗ ខ្ចី-សង ក្នុង១ឆ្នាំ',
        activities: '• រៀបចំប្រព័ន្ធគ្រប់គ្រងបណ្ណាល័យងាយស្រួល (មានកាតខ្ចីសៀវភៅ) និងជំរុញសិស្សឱ្យជ្រើសរើសសៀវភៅរឿង ឬសៀវភៅអានក្រៅថ្នាក់យកទៅអាននៅផ្ទះ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'បណ្ណារក្ស',
        stateBudget: 300000, communityBudget: 0, partnerBudget: 0, totalBudget: 300000
      },
      {
        id: 'c5-2-21',
        code: '៥.២',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៥. ដំណើរការបណ្ណាល័យ',
        expectedOutcome: 'ចំនួនដង គ្រូបង្រៀនម្នាក់ៗក្នុង១ឆ្នាំ នាំសិស្សចូលបណ្ណាល័យអនុវត្តសកម្មភាពអាន ដោយប្រើប្រាស់វិធីសាស្ត្រអំណាន',
        activities: '• បញ្ចូលម៉ោងអំណានក្នុងបណ្ណាល័យទៅក្នុងកាលវិភាគបង្រៀនផ្លូវការ ដោយប្រើប្រាស់វិធីសាស្ត្រអំណានជាគូ ឬអំណានស្ងាត់',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'បណ្ណារក្ស និងគ្រូបង្រៀន',
        stateBudget: 300000, communityBudget: 0, partnerBudget: 0, totalBudget: 300000
      },
      {
        id: 'c5-2-22',
        code: '៦.១',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៦. ការធ្វើអធិការកិច្ចផ្ទៃក្នុង',
        expectedOutcome: 'ភាគរយគ្រូបង្រៀនទទួលបានការផ្តល់ប្រឹក្សាគរុកោសល្យ/អធិការកិច្ចថ្នាក់រៀន យ៉ាងតិចម្តង/ខែ',
        activities: '• នាយកសាលា នាយករង ឬគ្រូឧទ្ទេសផ្ទៃក្នុង រៀបចំតារាងចុះអងើកការបង្រៀនក្នុងថ្នាក់រៀន (Classroom Observation) និងផ្តល់មតិកែលម្អ (Feedback) បែបស្ថាបនាដល់គ្រូ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'នាយក និងនាយករង',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-2-23',
        code: '៧.១',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៧. ការប្រជុំបច្ចេកទេស',
        expectedOutcome: 'ចំនួនដងសាលារៀនបានរៀបចំការប្រជុំបច្ចេកទេស',
        activities: '• រៀបចំកិច្ចប្រជុំបណ្តុំវិជ្ជាជីវៈគ្រូបង្រៀន (TLC) ដើម្បីពិភាក្សាពីបញ្ហាគរុកោសល្យ ការដោះស្រាយលំហាត់ពិបាក និងការរៀបចំកិច្ចតែងការបង្រៀនរួមគ្នា',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'ប្រធានក្រុមបច្ចេកទេស',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-2-24',
        code: '៨.១',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៨. ការអនុវត្តកម្មវិធីក្រៅម៉ោងសិក្សា',
        expectedOutcome: 'ចំនួនដងការប្រកួតប្រជែងអំណាន និងធ្វើលំហាត់គណិតវិទ្យាក្នុងមួយឆ្នាំ',
        activities: '• រៀបចំកម្មវិធីប្រកួតប្រជែងថ្នាក់រៀន និងថ្នាក់សាលា (ឧ. ការប្រកួតអានលឿន-យល់ន័យ និងប្រកួតដោះស្រាយលំហាត់គណិតវិទ្យាឆ្នើម)',
        q1: false, q2: true, q3: false, q4: true,
        responsiblePerson: 'គណៈកម្មការប្រកួតប្រជែង',
        stateBudget: 400000, communityBudget: 0, partnerBudget: 0, totalBudget: 400000
      },
      {
        id: 'c5-2-25',
        code: '៨.២',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៨. ការអនុវត្តកម្មវិធីក្រៅម៉ោងសិក្សា',
        expectedOutcome: 'ចំនួនក្លឹបសិក្សាបានបង្កើតដើម្បីជួយសិស្សរៀនយឺត និងជួយការងារផ្សេងៗរបស់សាលា',
        activities: '• បង្កើតក្លឹបសិក្សា (ក្លឹបអំណាន គណិតវិទ្យា និងក្លឹបបរិស្ថាន) ដោយមានការចាត់តាំងសិស្សពូកែជួយសិស្សខ្សោយ (Peer-to-Peer Support)',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូទទួលបន្ទុកក្លឹប',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-2-26',
        code: '៨.៣',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៨. ការអនុវត្តកម្មវិធីក្រៅម៉ោងសិក្សា',
        expectedOutcome: 'ចំនួនដងសិស្សានុសិស្សបានចុះទស្សនៈកិច្ចសិក្សានៅតាមទីកន្លែងនានា ក្នុងមួយឆ្នាំសិក្សា',
        activities: '• រៀបចំផែនការទស្សនកិច្ចសិក្សាទៅកាន់កសិដ្ឋាន វត្តអារាម មជ្ឈមណ្ឌលប្រវត្តិសាស្ត្រ ឬរោងចក្រក្នុងមូលដ្ឋាន ដើម្បីផ្សារភ្ជាប់ទ្រឹស្តីទៅនឹងការអនុវត្តជាក់ស្តែង',
        q1: false, q2: true, q3: false, q4: false,
        responsiblePerson: 'គណៈគ្រប់គ្រង និងគ្រូថ្នាក់ទី ៦',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-2-27',
        code: '៩.១',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៩. ការអនុវត្តការអប់រំសីលធម៌ ចរិយាធម៌',
        expectedOutcome: 'សាលារៀនមានកម្មវិធីលើកកម្ពស់ការអប់រំសីលធម៌ និងចរិយាធម៌ (ស្អាត សុភាព របៀប ទៀងពេល និងសមាធិ)',
        activities: '• អនុវត្តសកម្មភាពប្រចាំថ្ងៃដូចជា ការគោរពទង់ជាតិ ការពិនិត្យអនាម័យផ្ទាល់ខ្លួន ការធ្វើសមាធិ ៥ នាទីមុនចូលរៀន និងការអប់រំវិន័យបែបវិជ្ជមាន',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'ក្រុមប្រឹក្សាកុមារ និងគ្រូប្រចាំការ',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
      {
        id: 'c5-2-28',
        code: '៩.២',
        standardCode: 'ស្តង់ដាទី២',
        categoryTitle: '៩. ការអនុវត្តការអប់រំសីលធម៌ ចរិយាធម៌',
        expectedOutcome: 'ចំនួនដងព្រះសង្ឃនិមន្តមកផ្តល់ធម៌ទេសនាអប់រំ ក្នុង១ឆ្នាំ',
        activities: '• សហការជាមួយវត្តអារាមក្នុងមូលដ្ឋាន ដើម្បីនិមន្តព្រះសង្ឃមកទេសនាអប់រំពីសីលធម៌ កតញ្ញូតាធម៌ និងការប្រព្រឹត្តខ្លួនជាកូនល្អ សិស្សល្អ',
        q1: false, q2: true, q3: false, q4: true,
        responsiblePerson: 'គណៈកម្មការ គ.គ.ស',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
    ],
  },
  {
    id: 'c5-std-3',
    standardTitle: 'ស្តង់ដាទី៣៖ ការចូលរួមរបស់សហគមន៍',
    items: [
      {
        id: 'c5-3-1',
        code: '១.១',
        standardCode: 'ស្តង់ដាទី៣',
        categoryTitle: '១. ការបង្កើតនិងដំណើរការ គ.គ.ស និង គ.គ.ថ',
        expectedOutcome: 'ចំនួនដងគណៈកម្មការគ្រប់គ្រងសាលារៀន (គ.គ.ស.) ប្រជុំក្នុងមួយឆ្នាំ',
        activities: '• រៀបចំកាលវិភាគប្រជុំទៀងទាត់របស់ គ.គ.ស. និងកំណត់របៀបវារៈច្បាស់លាស់ (ពិភាក្សាពីផែនការយុទ្ធសាស្ត្រអភិវឌ្ឍសាលារៀន ការតាមដានការរីកចម្រើនរបស់សិស្ស និងការដោះស្រាយបញ្ហាប្រឈម)',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'ប្រធាន គ.គ.ស',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-3-2',
        code: '១.២',
        standardCode: 'ស្តង់ដាទី៣',
        categoryTitle: '១. ការបង្កើតនិងដំណើរការ គ.គ.ស និង គ.គ.ថ',
        expectedOutcome: 'ភាគរយថ្នាក់រៀនបង្កើត និងដំណើរការគណៈកម្មការគ្រប់គ្រងថ្នាក់រៀន (គ.គ.ថ)',
        activities: '• ណែនាំដល់គ្រូបន្ទុកបន្ទប់នីមួយៗឱ្យបង្កើត គ.គ.ថ. (តំណាងមាតាបិតាប្រចាំថ្នាក់) និងផ្តល់តួនាទីភារកិច្ចច្បាស់លាស់ក្នុងការជួយគាំទ្រសកម្មភាពអប់រំក្នុងថ្នាក់រៀន',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបន្ទុកថ្នាក់គ្រប់រូប',
        stateBudget: 400000, communityBudget: 0, partnerBudget: 0, totalBudget: 400000
      },
      {
        id: 'c5-3-3',
        code: '២.១',
        standardCode: 'ស្តង់ដាទី៣',
        categoryTitle: '២. ការចូលរួមរបស់សហគមន៍',
        expectedOutcome: 'សាលារៀនមានកិច្ចសហប្រតិបត្តិការភាពជាដៃគូវិនិយោគជាមួយវិស័យសាធារណៈ វិស័យឯកជន និងដៃគូអភិវឌ្ឍ',
        activities: '• រៀបចំសំណើគម្រោងអភិវឌ្ឍសាលារៀន (សាងសង់អគារ បង្គន់អនាម័យ បណ្ណាល័យ ឬបំពាក់សម្ភារបច្ចេកវិទ្យា) និងធ្វើបណ្តាញទំនាក់ទំនងជាមួយអាជ្ញាធរដែនដី សប្បុរសជន និងអង្គការដៃគូ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'នាយកសាលា និង គ.គ.ស',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-3-4',
        code: '២.២',
        standardCode: 'ស្តង់ដាទី៣',
        categoryTitle: '២. ការចូលរួមរបស់សហគមន៍',
        expectedOutcome: 'ភាគរយសិស្សត្រៀមនឹងបោះបង់ ឬបោះបង់ការសិក្សាបានត្រឡប់មករៀនវិញ ក្រោមការគាំទ្រពីសហគមន៍',
        activities: '• បង្កើតក្រុមការងារចុះអន្តរាគមន៍បន្ទាន់ (នាយកសាលា លោកគ្រូ អ្នកគ្រូ និងអាជ្ញាធរ/គ.គ.ស.) ដើម្បីចុះសួរសុខទុក្ខ និងស្វែងរកមូលហេតុនៅពេលសិស្សអវត្តមានយូរ ឬបោះបង់ ព្រមទាំងផ្តល់ការឧបត្ថម្ភគាំទ្រ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'ក្រុមការងារអន្តរាគមន៍',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-3-5',
        code: '៣.១',
        standardCode: 'ស្តង់ដាទី៣',
        categoryTitle: '៣. ការគាំទ្ររបស់សហគមន៍',
        expectedOutcome: 'បរិមាណចំណូលមូលនិធិបង់ចូលសាលារៀន',
        activities: '• រៀបចំយុទ្ធនាការកៀរគរមូលនិធិសហគមន៍ (Community Fundraising) ប្រកបដោយតម្លាភាព ដោយមានការចូលរួមពីអាណាព្យាបាល សប្បុរសជន និងសហគមន៍មូលដ្ឋាន ដើម្បីយកមកទ្រទ្រង់សកម្មភាពអភិវឌ្ឍសាលារៀន និងជួយសិស្សក្រីក្រ',
        q1: false, q2: true, q3: false, q4: true,
        responsiblePerson: 'គ.គ.ស និងគណៈគ្រប់គ្រង',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
    ],
  },
  {
    id: 'c5-std-4',
    standardTitle: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    items: [
      {
        id: 'c5-4-1',
        code: '១.១',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '១. ការគ្រប់គ្រងរដ្ឋបាលទូទៅ',
        expectedOutcome: 'ការរៀបចំទីចាត់ការ ទុកដាក់ឯកសារ មានសណ្តាប់ធ្នាប់ និងមានរបៀបរៀបរយ',
        activities: '• រៀបចំទូដាក់ឯកសារតាមប្រភេទ (ឯកសាររដ្ឋបាល បុគ្គលិក បរទេស និងគណនេយ្យ) បិទស្លាកចំណាំច្បាស់លាស់ និងប្រើប្រាស់ប្រព័ន្ធរក្សាទុកឯកសារឌីជីថល (Soft Copy)',
        q1: true, q2: false, q3: false, q4: false,
        responsiblePerson: 'បុគ្គលិករដ្ឋបាល',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-4-2',
        code: '១.២',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '១. ការគ្រប់គ្រងរដ្ឋបាលទូទៅ',
        expectedOutcome: 'សាលារៀនប្រើប្រាស់ App សម្រាប់គ្រប់គ្រងទិន្នន័យសាលារៀន',
        activities: '• ជំរុញ និងបណ្តុះបណ្តាលនាយកសាលា និងបុគ្គលិករដ្ឋបាលឱ្យប្រើប្រាស់កម្មវិធីគ្រប់គ្រងទិន្នន័យ (Database App) ឬប្រព័ន្ធព័ត៌មានអប់រំផ្សេងៗសម្រាប់កត់ត្រាវត្តមាន ពិន្ទុ និងស្ថិតិសិស្ស',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'នាយកសាលា និងរដ្ឋបាល',
        stateBudget: 400000, communityBudget: 0, partnerBudget: 0, totalBudget: 400000
      },
      {
        id: 'c5-4-3',
        code: '១.៣',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '១. ការគ្រប់គ្រងរដ្ឋបាលទូទៅ',
        expectedOutcome: 'ភាគរយគ្រូលើស-ខ្វះ ត្រូវបានថយចុះ',
        activities: '• ធ្វើបច្ចុប្បន្នភាពតារាងបែងចែកម៉ោងបង្រៀនឱ្យបានច្បាស់លាស់ និងស្នើសុំការអន្តរាគមន៍ ឬការបំពេញបន្ថែមគ្រូបង្រៀនពីការិយាល័យអប់រំស្រុក/ខណ្ឌ ឬមន្ទីរអប់រំ',
        q1: true, q2: false, q3: false, q4: false,
        responsiblePerson: 'នាយកសាលា',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
      {
        id: 'c5-4-4',
        code: '១.៤',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '១. ការគ្រប់គ្រងរដ្ឋបាលទូទៅ',
        expectedOutcome: 'សាលារៀនមានកម្មវិធីប្រជុំប្រចាំខែ ត្រីមាស និងឆមាសត្រឹមត្រូវ',
        activities: '• រៀបចំប្រតិទិនការងារប្រចាំឆ្នាំ ដោយកំណត់ថ្ងៃប្រជុំអធិការកិច្ចផ្ទៃក្នុង ប្រជុំបច្ចេកទេស និងប្រជុំគរុកោសល្យឱ្យបានច្បាស់លាស់',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'នាយកសាលា',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
      {
        id: 'c5-4-5',
        code: '២.១',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '២. ការរៀបចំផែនការអភិវឌ្ឍសាលារៀន',
        expectedOutcome: 'ផែនការយុទ្ធសាស្ត្រអភិវឌ្ឍន៍សាលារៀន ៥ឆ្នាំ ផែនការយុទ្ធសាស្ត្រថវិកា ៣ឆ្នាំ ផែនការថវិកាប្រចាំឆ្នាំ និងផែនការប្រតិបត្តិប្រចាំឆ្នាំ បានរៀបចំតាមការណែនាំ',
        activities: '• បង្កើតក្រុមការងារកសាងផែនការអភិវឌ្ឍសាលារៀន (ដោយមានការចូលរួមពី គ.គ.ស. និងសហគមន៍) ដើម្បីកំណត់គោលដៅ វិភាគតម្រូវការ និងបែងចែកថវិកាឱ្យស្របតាមស្តង់ដាគុណភាពអប់រំ',
        q1: true, q2: false, q3: false, q4: false,
        responsiblePerson: 'គណៈកម្មការផែនការសាលា',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-4-6',
        code: '៣.១',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៣. ការវាយតម្លៃការបំពេញការងាររបស់បុគ្គលិក',
        expectedOutcome: 'ចំនួនគ្រូបង្រៀន និងបុគ្គលិកអប់រំ បានចុះកិច្ចព្រមព្រៀងលទ្ធផលការងារប្រចាំឆ្នាំ',
        activities: '• រៀបចំកិច្ចព្រមព្រៀងការងារ (Performance Agreement) ដែលកំណត់សូចនាករគោលដៅច្បាស់លាស់សម្រាប់បុគ្គលិកអប់រំ និងថ្នាក់ដឹកនាំសាលា',
        q1: true, q2: false, q3: false, q4: true,
        responsiblePerson: 'នាយកសាលា',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-4-7',
        code: '៣.២',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៣. ការវាយតម្លៃការបំពេញការងាររបស់បុគ្គលិក',
        expectedOutcome: 'ចំនួននាយកសាលានិងនាយករង បានចុះកិច្ចព្រមព្រៀងលទ្ធផលការងារប្រចាំឆ្នាំ',
        activities: '• ចុះហត្ថលេខាលើកិច្ចព្រមព្រៀងនៅដើមឆ្នាំសិក្សា (ខែតុលា) និងធ្វើការវាយតម្លៃលទ្ធផលនៅចុងឆ្នាំសិក្សា (ខែឧសភា)',
        q1: true, q2: false, q3: false, q4: true,
        responsiblePerson: 'នាយកសាលា និងការិយាល័យអប់រំ',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
      {
        id: 'c5-4-8',
        code: '៤.១',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៤. រង្វាយតម្លៃលទ្ធផលសិក្សា',
        expectedOutcome: 'ការរៀបចំធ្វើតេស្តស្តង់ដាដើមឆ្នាំ ឬចុងឆ្នាំ ប្រចាំខែ ឆមាស និងតេស្តស្តង់ដា ថ្នាក់ទី៣ និងទី៦ បានរៀបចំទៀងទាត់',
        activities: '• រៀបចំកាលវិវត្តនៃការធ្វើតេស្ត ការត្រួតពិនិត្យគុណភាពសំណួរ និងការកែសន្លឹកកិច្ចការប្រកបដោយភាពយុត្តិធម៌ និងតម្លាភាព',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គណៈកម្មការវាយតម្លៃលទ្ធផល',
        stateBudget: 150000, communityBudget: 0, partnerBudget: 0, totalBudget: 150000
      },
      {
        id: 'c5-4-9',
        code: '៥.១',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
        expectedOutcome: 'ការលើកកម្ពស់សេវាថែទាំសុខភាពបឋម',
        activities: '• មានសៀវភៅសុខភាពសិស្ស និងសហការជាមួយមណ្ឌលសុខភាពដើម្បីពិនិត្យសុខភាពសិស្ស និងចាក់វ៉ាក់សាំង',
        q1: true, q2: false, q3: true, q4: false,
        responsiblePerson: 'គ្រូសុខភាពសិក្សា',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
      {
        id: 'c5-4-10',
        code: '៥.២',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
        expectedOutcome: 'សាលារៀនបានរៀបចំកម្មវិធីពិនិត្យសុខភាពសិស្ស',
        activities: '• សហការជាមួយមណ្ឌលសុខភាពដើម្បីពិនិត្យសុខភាពសិស្ស និងចាក់វ៉ាក់សាំង',
        q1: true, q2: false, q3: true, q4: false,
        responsiblePerson: 'គ្រូសុខភាពសិក្សា',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
      {
        id: 'c5-4-11',
        code: '៥.៣',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
        expectedOutcome: 'ការលើកកម្ពស់ទឹកស្អាត និងអនាម័យ',
        activities: '• មានវេនសម្អាត និងការអនុវត្តអនាម័យជាប្រចាំដោយក្រុមប្រឹក្សាកុមារ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'ក្រុមប្រឹក្សាកុមារ',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
      {
        id: 'c5-4-12',
        code: '៥.៤',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
        expectedOutcome: 'ការលើកកម្ពស់សុវត្ថិភាពចំណីអាហារ និងអាហារប្រកបដោយសុខភាព',
        activities: '• មានកិច្ចសន្យា និងការលក់ដូរចំណីអាហារមានសុវត្ថិភាពក្នុងបរិវេណសាលា',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គណៈកម្មការសុខភាពសាលា',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
      {
        id: 'c5-4-13',
        code: '៥.៥',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
        expectedOutcome: 'ការអនុវត្តមុខវិជ្ជាអប់រំសុខភាព',
        activities: '• មានកម្មវិធីបង្រៀន និងបានបញ្ចូលទៅក្នុងកាលវិភាគបង្រៀន',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបង្រៀនគ្រប់ថ្នាក់',
        stateBudget: 50000, communityBudget: 0, partnerBudget: 0, totalBudget: 50000
      },
      {
        id: 'c5-4-14',
        code: '៥.៦',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
        expectedOutcome: 'ការលើកកម្ពស់បរិស្ថានស្អាត បៃតង សុវត្ថិភាព អនាម័យ និងមេត្រីភាព',
        activities: '• រៀបចំកន្លែងលាងដៃ ធុងទឹកស្អាត បន្ទប់ទឹកស្អាត និងហាមឃាត់ការលក់ចំណីអាហារគ្មានស្លាកសញ្ញា ឬខូចគុណភាពក្នុងសាលា',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គណៈកម្មការបរិស្ថានសាលា',
        stateBudget: 400000, communityBudget: 0, partnerBudget: 0, totalBudget: 400000
      },
      {
        id: 'c5-4-15',
        code: '៥.៧',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
        expectedOutcome: 'ការរក្សាសន្តិសុខ សណ្ដាប់ធ្នាប់ ការការពារកុមារ ការបង្ការគ្រោះមហន្តរាយនានា',
        activities: '• រៀបចំកន្លែងលាងដៃ ធុងទឹកស្អាត បន្ទប់ទឹកស្អាត និងហាមឃាត់ការលក់ចំណីអាហារគ្មានស្លាកសញ្ញា ឬខូចគុណភាពក្នុងសាលា',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គណៈគ្រប់គ្រង និងគ្រូប្រចាំការ',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-4-16',
        code: '៥.៨',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
        expectedOutcome: 'សាលារៀនបានអនុវត្តសកម្មភាពអប់រំកាយនិងកីឡា',
        activities: '• រៀបចំសកម្មភាពអនាម័យថ្ងៃសុក្រ បៃតង និងសកម្មភាពកីឡាពេលព្រឹក ឬក្រៅម៉ោង',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូអប់រំកាយ និងកីឡា',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-4-17',
        code: '៦.១',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៦. ការអភិវឌ្ឍហេដ្ឋារចនាសម្ព័ន្ធអប់រំ',
        expectedOutcome: 'សាលារៀនមានបណ្តាញអគ្គិសនី បំពាក់អ៊ីនធើណិត',
        activities: '• កៀរគររកជំនួយពីសប្បុរសជន អាជ្ញាធរ និងអង្គការដៃគូ ដើម្បីបំពាក់សម្ភារៈបច្ចេកវិទ្យា',
        q1: true, q2: false, q3: false, q4: false,
        responsiblePerson: 'នាយកសាលា និង គ.គ.ស',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-4-18',
        code: '៦.២',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៦. ការអភិវឌ្ឍហេដ្ឋារចនាសម្ព័ន្ធអប់រំ',
        expectedOutcome: 'ភាគរយបន្ទប់រៀនបំពាក់ឧបករណ៍សិក្សាទំនើប (LCD, Smart TV, Smart Board)',
        activities: '• កៀរគររកជំនួយពីសប្បុរសជន អាជ្ញាធរ និងអង្គការដៃគូ ដើម្បីបំពាក់សម្ភារៈបច្ចេកវិទ្យា (Smart TV, Internet) និងជួសជុលហេដ្ឋារចនាសម្ព័ន្ធសាលារៀន',
        q1: true, q2: false, q3: false, q4: false,
        responsiblePerson: 'គណៈកម្មការអភិវឌ្ឍន៍សាលា',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-4-19',
        code: '៦.៣',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៦. ការអភិវឌ្ឍហេដ្ឋារចនាសម្ព័ន្ធអប់រំ',
        expectedOutcome: 'សាលារៀនមានបណ្ណាល័យ',
        activities: '• រៀបចំកាលវិភាគប្រើប្រាស់បន្ទប់បណ្ណាល័យឱ្យបានច្បាស់លាស់ និងបំពាក់សៀវភៅបន្ថែម',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'បណ្ណារក្ស',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-4-20',
        code: '៦.៤',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៦. ការអភិវឌ្ឍហេដ្ឋារចនាសម្ព័ន្ធអប់រំ',
        expectedOutcome: 'សាលារៀនមានបន្ទប់កុំព្យូទ័រសម្រាប់សិស្សរៀន',
        activities: '• រៀបចំកាលវិភាគប្រើប្រាស់បន្ទប់កុំព្យូទ័រ និងការថែទាំឧបករណ៍កុំព្យូទ័រឱ្យដំណើរការល្អ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូបច្ចេកវិទ្យា ICT',
        stateBudget: 400000, communityBudget: 0, partnerBudget: 0, totalBudget: 400000
      },
      {
        id: 'c5-4-21',
        code: '៦.៥',
        standardCode: 'ស្តង់ដាទី៤',
        categoryTitle: '៦. ការអភិវឌ្ឍហេដ្ឋារចនាសម្ព័ន្ធអប់រំ',
        expectedOutcome: 'សាលារៀនមានទីលានកីឡារួមមាន៖ តារាបាល់ទះ បាល់ទាត់ បាល់បោះ វាយសី...',
        activities: '• រៀបចំទីលានបាល់ទាត់ និងមានសកម្មភាពហ្វឹកហាត់ជាប្រចាំ',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គ្រូអប់រំកាយ',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
    ],
  },
  {
    id: 'c5-std-5',
    standardTitle: 'ស្តង់ដាទី៥៖ គណនេយ្យភាព',
    items: [
      {
        id: 'c5-5-1',
        code: '១.១',
        standardCode: 'ស្តង់ដាទី៥',
        categoryTitle: '១. វេទិកាសាធារណៈ',
        expectedOutcome: 'សាលារៀនរៀបចំកម្មវិធីជួបប្រជុំជាមួយមាតាបិតា អ្នកអាណាព្យាបាលសិស្ស និងសហគមន៍',
        activities: '• រៀបចំវេទិកាសាធារណៈប្រចាំឆ្នាំ ឬប្រចាំឆមាស ដើម្បីរបាយការណ៍ពីសមិទ្ធផលការងារ ថវិកា និងបញ្ហាប្រឈមរបស់សាលារៀន ព្រមទាំងបើកទូលាយឱ្យមាតាបិតា និងសហគមន៍ផ្តល់មតិយោបល់ និងសំណូមពរនានា',
        q1: false, q2: true, q3: false, q4: true,
        responsiblePerson: 'នាយកសាលា និង គ.គ.ស',
        stateBudget: 400000, communityBudget: 0, partnerBudget: 0, totalBudget: 400000
      },
      {
        id: 'c5-5-2',
        code: '២.១',
        standardCode: 'ស្តង់ដាទី៥',
        categoryTitle: '២. ការផ្សាយព័ត៌មានជាសាធារណៈ',
        expectedOutcome: 'លទ្ធផលតេស្តវាយតម្លៃស្តង់ដា និងព័ត៌មាននានាត្រូវបានអនុម័តដោយ គ.គ.ស និង/ឬ បិទផ្សាយជាសាធារណៈ',
        activities: '• បង្កើតក្តារខៀន ឬកន្លែងបិទផ្សាយព័ត៌មាន (Notice Board) នៅមុខទីចាត់ការសាលា ដើម្បីបង្ហាញពីរបាយការណ៍ហិរញ្ញវត្ថុ ស្ថិតិសិស្ស និងលទ្ធផលតេស្តវាយតម្លៃស្តង់ដា ដោយមានការពិនិត្យ និងអនុម័តពីគណៈកម្មការគ្រប់គ្រងសាលារៀន (គ.គ.ស.) ជាមុន',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'គណៈគ្រប់គ្រងសាលា',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-5-3',
        code: '៣.១',
        standardCode: 'ស្តង់ដាទី៥',
        categoryTitle: '៣. ការទទួលបានការគាំទ្រពីថ្នាក់ជាតិ',
        expectedOutcome: 'ចំនួនដងនាយកសាលា និងនាយករង បានទទួលការហ្វឹកហាត់អនុវត្តស្តង់ដាសាលារៀនគំរូពីនាយកសាលាផ្សេងៗឬមកពីថ្នាក់លើ',
        activities: '• ស្នើសុំ ឬចូលរួមវគ្គបណ្តុះបណ្តាល និងសិក្ខាសាលាស្ដីពីការអនុវត្តស្តង់ដាសាលារៀនគំរូដែលរៀបចំដោយការិយាល័យអប់រំ មន្ទីរអប់រំ ឬចូលរួមក្នុងកម្មវិធីទស្សនកិច្ចសិក្សាស្វែងយល់ពីបទពិសោធន៍នៅសាលារៀនគំរូផ្សេងទៀត',
        q1: true, q2: true, q3: true, q4: true,
        responsiblePerson: 'នាយក និងនាយករង',
        stateBudget: 200000, communityBudget: 0, partnerBudget: 0, totalBudget: 200000
      },
      {
        id: 'c5-5-4',
        code: '៣.២',
        standardCode: 'ស្តង់ដាទី៥',
        categoryTitle: '៣. ការទទួលបានការគាំទ្រពីថ្នាក់ជាតិ',
        expectedOutcome: 'ភាគរយគ្រូបង្រៀនបានទទួលការហ្វឹកហាត់ការអនុវត្តកញ្ចប់សម្ភារៈអំណាន និងគណិតវិទ្យាថ្នាក់ដំបូង ឬវិធីសាស្ត្របង្រៀនភាសាខ្មែរ ឬគណិតវិទ្យា',
        activities: '• រៀបចំវគ្គបណ្តុះបណ្តាលផ្ទៃក្នុងសាលា (School-based Training) ដោយចាត់តាំងគ្រូស្នូលដែលធ្លាប់បាន training ពីថ្នាក់លើ មកចែករំលែកចំណេះដឹង និងបច្ចេកទេសបង្រៀនថ្មីៗដល់គ្រូបង្រៀនទូទាំងសាលា',
        q1: true, q2: false, q3: true, q4: false,
        responsiblePerson: 'គ្រូស្នូល និងនាយករង',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
      {
        id: 'c5-5-5',
        code: '៣.៣',
        standardCode: 'ស្តង់ដាទី៥',
        categoryTitle: '៣. ការទទួលបានការគាំទ្រពីថ្នាក់ជាតិ',
        expectedOutcome: 'ភាគរយគ្រូបង្រៀនបំពេញទស្សនៈកិច្ចសិក្សា ទៅសាលាផ្សេងៗក្នុងមួយឆ្នាំ',
        activities: '• រៀបចំផែនការទស្សនកិច្ចសិក្សាសហការគ្នារវាងសាលារៀនក្នុងបណ្តុំសាលាគោលដៅ (Cluster Schools) ដើម្បីឱ្យគ្រូអាចចូលរួមសង្កេតការណ៍បង្រៀនជាក់ស្តែង និងផ្លាស់ប្តូរទស្សនៈ និងបទពិសោធន៍គរុកោសល្យល្អៗពីគ្នាទៅវិញទៅមក',
        q1: false, q2: true, q3: false, q4: false,
        responsiblePerson: 'នាយកសាលា និងគ្រូបង្រៀន',
        stateBudget: 100000, communityBudget: 0, partnerBudget: 0, totalBudget: 100000
      },
    ],
  },
];
