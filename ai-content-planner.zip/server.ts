import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Server-side initialization of Gemini client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const KHMER_PLAN_SYSTEM_INSTRUCTION = `អ្នកជាអ្នកជំនាញជាន់ខ្ពស់ផ្នែករៀបចំផែនការយុទ្ធសាស្ត្រ និងផែនការប្រតិបត្តិសាលារៀន/អង្គភាព (School Operational Plan / Action Plan Expert) នៃព្រះរាជាណាចក្រកម្ពុជា។
ច្បាប់នៃការសរសេរ៖
១. ប្រើប្រាស់ភាសាខ្មែររដ្ឋបាលផ្លូវការ (Formal Administrative Khmer) មានលក្ខណៈគរុកោសល្យ និងស្តង់ដារក្រសួងអប់រំ យុវជន និងកីឡា។
២. ខ្លឹមសារត្រូវជាក់ស្តែង មានតួលេខ សូចនាករវាស់វែងបាន (SMART: Specific, Measurable, Achievable, Relevant, Time-bound)។
៣. រចនាសម្ព័ន្ធអត្ថបទត្រូវរៀបរៀបមានកថាខណ្ឌច្បាស់លាស់ ប្រើប្រាស់លេខរៀង ឬចំណុចផ្ដើម (Bullet points) ដើម្បីងាយស្រួលអាន។
៤. ហាមប្រើពាក្យសាមញ្ញទូទៅដែលគ្មានខ្លឹមសារ។
៥. ផ្តល់នូវទិន្នន័យ ការវិភាគ ដំណោះស្រាយ និងសកម្មភាពជាក់ស្ដែងសមស្របទៅនឹងបរិបទកម្ពុជា។`;

// Endpoint: Generate Full Operational Plan
app.post('/api/plan/generate-all', async (req: Request, res: Response) => {
  try {
    const { schoolName, academicYear, location, schoolType, priorities, challenges, targetGoals } = req.body;

    const prompt = `សូមជួយរៀបចំខ្លឹមសារពេញលេញនៃ "ផែនការប្រតិបត្តិ" (School / Institutional Operational Plan) សម្រាប់៖
- ឈ្មោះសាលា/ស្ថាប័ន៖ ${schoolName || 'សាលារៀនគំរូ'}
- កម្រិត/ប្រភេទ៖ ${schoolType || 'សាលាបឋមសិក្សា'}
- ឆ្នាំសិក្សា/អនុវត្ត៖ ${academicYear || '២០២៤-២០២៥'}
- ទីតាំង៖ ${location || 'រាជធានីភ្នំពេញ'}
- ទិសដៅអាទិភាព៖ ${priorities || 'លើកកម្ពស់លទ្ធផលសិក្សាសិស្ស បំណិនអាន និងគណិតវិទ្យា ព្រមទាំងការពង្រឹងវិន័យ'}
- បញ្ហាប្រឈមចម្បង៖ ${challenges || 'កង្វះសម្ភារឧបទេស និងការចូលរួមរបស់មាតាបិតានៅមានកម្រិត'}
- គោលដៅជាក់លាក់៖ ${targetGoals || 'បង្កើនអត្រាសិស្សជាប់ថ្នាក់ដល់ ៩៥% និងកាត់បន្ថយអត្រាបោះបង់ការសិក្សាឱ្យនៅក្រោម ២%'}

រចនាសម្ព័ន្ធឯកសារត្រូវតែអនុលោមតាមទម្រង់ស្តង់ដារ ៦ ជំពូកដូចខាងក្រោម៖
១. សេចក្តីផ្តើម (បរិបទសាលា បរិយាកាសទូទៅ សារៈសំខាន់នៃផែនការ)
២. វឌ្ឍនភាព និងបញ្ហាប្រឈម
   - វឌ្ឍនភាព៖
     + លទ្ធផលសិក្សារបស់សិស្ស
     + ការបង្រៀន និងរៀន
     + ការចូលរួមរបស់សហគមន៍
     + ដំណើរការប្រតិបត្តិរបស់សាលា
     + គណនេយ្យភាព
   - បញ្ហាប្រឈម៖
     + លទ្ធផលសិក្សារបស់សិស្ស
     + ការបង្រៀន និងរៀន
     + ការចូលរួមរបស់សហគមន៍
     + ដំណើរការប្រតិបត្តិរបស់សាលា
     + គណនេយ្យភាព
៣. គោលបំណង (គោលបំណងរួម និងគោលបំណងជាក់លាក់)
៤. គោលដៅសមិទ្ធកម្ម (សូចនាករស្នូល និងកម្រិតសម្រេច)
៥. សកម្មភាពអនុវត្ត (សកម្មភាពគន្លឹះយុទ្ធសាស្ត្រនីមួយៗ)
៦. សេចក្តីសន្និដ្ឋាន និងអនុសាសន៍

សូមផ្តល់ជាទម្រង់ JSON ដែលមាន Object ដូចខាងក្រោម៖
{
  "title": "ផែនការប្រតិបត្តិ...",
  "subtitle": "សម្រាប់ឆ្នាំសិក្សា...",
  "sections": [
    {
      "id": "sec-1",
      "code": "១",
      "title": "សេចក្តីផ្តើម",
      "content": "ខ្លឹមសារកថាខណ្ឌសេចក្តីផ្តើម...",
      "subsections": []
    },
    {
      "id": "sec-2",
      "code": "២",
      "title": "វឌ្ឍនភាព និងបញ្ហាប្រឈម",
      "content": "សេចក្តីសង្ខេបជារួមអំពីស្ថានភាព...",
      "subsections": [
        {
          "id": "sec-2-1",
          "code": "២.១",
          "title": "វឌ្ឍនភាព",
          "content": "",
          "items": [
            { "id": "sec-2-1-1", "title": "លទ្ធផលសិក្សារបស់សិស្ស", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-1-2", "title": "ការបង្រៀន និងរៀន", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-1-3", "title": "ការចូលរួមរបស់សហគមន៍", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-1-4", "title": "ដំណើរការប្រតិបត្តិរបស់សាលា", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-1-5", "title": "គណនេយ្យភាព", "content": "ខ្លឹមសារលម្អិត..." }
          ]
        },
        {
          "id": "sec-2-2",
          "code": "២.២",
          "title": "បញ្ហាប្រឈម",
          "content": "",
          "items": [
            { "id": "sec-2-2-1", "title": "លទ្ធផលសិក្សារបស់សិស្ស", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-2-2", "title": "ការបង្រៀន និងរៀន", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-2-3", "title": "ការចូលរួមរបស់សហគមន៍", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-2-4", "title": "ដំណើរការប្រតិបត្តិរបស់សាលា", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-2-5", "title": "គណនេយ្យភាព", "content": "ខ្លឹមសារលម្អិត..." }
          ]
        }
      ]
    },
    {
      "id": "sec-3",
      "code": "៣",
      "title": "គោលបំណង",
      "content": "ខ្លឹមសារគោលបំណងរួម និងជាក់លាក់...",
      "subsections": []
    },
    {
      "id": "sec-4",
      "code": "៤",
      "title": "គោលដៅសមិទ្ធកម្ម",
      "content": "ខ្លឹមសារគោលដៅសមិទ្ធកម្ម និងសូចនាករ...",
      "subsections": []
    },
    {
      "id": "sec-5",
      "code": "៥",
      "title": "សកម្មភាពអនុវត្ត",
      "content": "សេចក្តីណែនាំអំពីសកម្មភាពអនុវត្ត...",
      "subsections": []
    },
    {
      "id": "sec-6",
      "code": "៦",
      "title": "សេចក្តីសន្និដ្ឋាន",
      "content": "ខ្លឹមសារសេចក្តីសន្និដ្ឋាន និងសំណូមពរ...",
      "subsections": []
    }
  ],
  "actionMatrix": [
    {
      "id": "act-1",
      "activity": "រៀបចំការប្រជុំបច្ចេកទេស និងគណៈកម្មការអភិវឌ្ឍន៍សាលារៀន",
      "indicator": "ប្រជុំទៀងទាត់ ១ដង/ខែ កំណត់ហេតុ និងវត្តមាន ១០០%",
      "timeline": "ត្រីមាសទី ១ ដល់ ទី ៤",
      "budget": "១,២០០,០០០ រៀល",
      "budgetSource": "ថវិកាដំណើរការសាលា (PB)",
      "responsiblePerson": "នាយកសាលា និងប្រធានក្រុមបច្ចេកទេស"
    },
    {
      "id": "act-2",
      "activity": "ពង្រឹងការបង្រៀន និងរៀនបំណិនអាន និងគណិតវិទ្យាថ្នាក់ដំបូង",
      "indicator": "សិស្ស ៩០% អាចអាន និងធ្វើប្រមាណវិធីស្ទាត់ជំនាញ",
      "timeline": "ពេញមួយឆ្នាំសិក្សា",
      "budget": "២,០០០,០០០ រៀល",
      "budgetSource": "ថវិការដ្ឋ និងដៃគូអភិវឌ្ឍន៍",
      "responsiblePerson": "គ្រូបង្រៀនថ្នាក់ទី ១-៣"
    },
    {
      "id": "act-3",
      "activity": "យុទ្ធនាការកៀរគរសហគមន៍ និងការជួបមាតាបិតាសិស្ស",
      "indicator": "មាតាបិតា ៨៥% ចូលរួមប្រជុំ និងតាមដានលទ្ធផលកូន",
      "timeline": "ដើមឆ្នាំ និងឆមាសទី ១-២",
      "budget": "៨០០,០០០ រៀល",
      "budgetSource": "ការចូលរួមរបស់សហគមន៍",
      "responsiblePerson": "គណៈកម្មការទ្រទ្រង់សាលា"
    },
    {
      "id": "act-4",
      "activity": "ការកែលម្អបរិស្ថានសាលារៀន បន្ទប់រៀន និងបណ្ណាល័យស្ដង់ដារ",
      "indicator": "បណ្ណាល័យដំណើរការសកម្ម មានសៀវភៅអានគ្រប់គ្រាន់",
      "timeline": "ត្រីមាសទី ១ និងទី ២",
      "budget": "៣,៥០០,០០០ រៀល",
      "budgetSource": "សប្បុរសជន និងថវិកា PB",
      "responsiblePerson": "នាយករង និងបណ្ណារក្ស"
    },
    {
      "id": "act-5",
      "activity": "ការត្រួតពិនិត្យ តាមដាន និងវាយតម្លៃផ្ទៃក្នុងប្រចាំឆមាស",
      "indicator": "របាយការណ៍វាយតម្លៃ ២ លើកក្នុងមួយឆ្នាំ",
      "timeline": "ចុងត្រីមាសទី ២ និងទី ៤",
      "budget": "៦០០,០០០ រៀល",
      "budgetSource": "ថវិកា PB",
      "responsiblePerson": "ក្រុមអធិការកិច្ចផ្ទៃក្នុង"
    }
  ]
}
សំខាន់៖ សូមឆ្លើយតបតែ JSON សុទ្ធ ដោយគ្មានកូដ Markdown backticks ឬអត្ថបទបន្ថែមក្រៅពី JSON ឡើយ។`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: KHMER_PLAN_SYSTEM_INSTRUCTION,
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      // Clean up in case there are codeblocks
      const cleaned = text.replace(/```json/gi, '').replace(/```/gi, '').trim();
      data = JSON.parse(cleaned);
    }

    res.json({ success: true, plan: data });
  } catch (error: any) {
    console.error('Error generating plan:', error);
    res.status(500).json({ success: false, error: error.message || 'បរាជ័យក្នុងការបង្កើតផែនការ' });
  }
});

// Endpoint: Generate / Refine Specific Section
app.post('/api/plan/generate-section', async (req: Request, res: Response) => {
  try {
    const { sectionTitle, parentTitle, currentContent, context, action, customInstruction } = req.body;

    let instructionDetails = '';
    switch (action) {
      case 'expand':
        instructionDetails = 'សូមពង្រីកខ្លឹមសារឱ្យកាន់តែលម្អិត ស៊ីជម្រៅ បន្ថែមឧទាហរណ៍ជាក់ស្តែង វិធានការដោះស្រាយ និងទិន្នន័យគរុកោសល្យ/រដ្ឋបាលជាក់ស្ដែង។';
        break;
      case 'formalize':
        instructionDetails = 'សូមកែសម្រួលពាក្យពេចន៍ឱ្យកាន់តែមានលក្ខណៈរដ្ឋបាលផ្លូវការ ត្រឹមត្រូវតាមក្បួនខ្នាតលិខិតបទដ្ឋានគតិយុត្តិ និងគរុកោសល្យកម្ពុជា។';
        break;
      case 'summarize':
        instructionDetails = 'សូមសង្ខេបខ្លឹមសារឱ្យនៅខ្លី ខ្លឹម ចំចំណុចគន្លឹះ ដោយមិនបាត់បង់អត្ថន័យស្នូល។';
        break;
      case 'add_indicators':
        instructionDetails = 'សូមបន្ថែមសូចនាករគន្លឹះ (KPIs) ភាគរយជាក់លាក់ និងទិន្នន័យវាស់វែងសមិទ្ធផលចូលក្នុងខ្លឹមសារ។';
        break;
      case 'custom':
        instructionDetails = `សូមកែប្រែ ឬបន្ថែមតាមការណែនាំ៖ ${customInstruction || ''}`;
        break;
      default:
        instructionDetails = 'សូមសរសេរខ្លឹមសារថ្មីឱ្យមានលក្ខណៈទូលំទូលាយ មានអត្ថន័យជ្រាលជ្រៅ និងស្របតាមក្បួនខ្នាតរដ្ឋបាល។';
    }

    const prompt = `ផ្នែកដែលត្រូវសរសេរ/កែសម្រួល៖
- ចំណងជើងមេ៖ ${parentTitle || 'ផែនការប្រតិបត្តិ'}
- ចំណងជើងផ្នែក៖ ${sectionTitle}
- បរិបទរួម៖ ${JSON.stringify(context || {})}
- ខ្លឹមសារបច្ចុប្បន្ន (បើមាន)៖ ${currentContent || '(នៅទទេ)'}

ការណែនាំជាក់លាក់៖
${instructionDetails}

លក្ខខណ្ឌ៖
- សរសេរជាភាសាខ្មែរផ្លូវការ ត្រឹមត្រូវតាមវេយ្យាករណ៍ និងវចនានុក្រមសម្ដេចព្រះសង្ឃរាជ ជួន ណាត។
- រៀបចំកថាខណ្ឌ និងចំណុចៗឱ្យមានសណ្ដាប់ធ្នាប់ ងាយស្រួលយកទៅដាក់ក្នុងឯកសារផ្លូវការ។
- ឆ្លើយតបតែអត្ថបទខ្លឹមសារសុទ្ធ ដោយមិនបាច់សរសេរសេចក្តីគួរសម ឬពាក្យណែនាំខាងក្រៅឡើយ។`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: KHMER_PLAN_SYSTEM_INSTRUCTION,
      },
    });

    res.json({ success: true, content: response.text });
  } catch (error: any) {
    console.error('Error generating section:', error);
    res.status(500).json({ success: false, error: error.message || 'បរាជ័យក្នុងការកែសម្រួលផ្នែកនេះ' });
  }
});

// Endpoint: Generate Action Matrix Table Rows
app.post('/api/plan/generate-matrix', async (req: Request, res: Response) => {
  try {
    const { schoolName, priorities, targetGoals, currentMatrix } = req.body;

    const prompt = `សូមបង្កើត ឬបន្ថែមតារាងម៉ាទ្រីសសកម្មភាពអនុវត្ត (Action Matrix for School/Institutional Operational Plan) សម្រាប់៖
- ស្ថាប័ន/សាលារៀន៖ ${schoolName || 'សាលារៀន'}
- អាទិភាព៖ ${priorities || 'លើកកម្ពស់គុណភាពបង្រៀន និងរៀន ការគ្រប់គ្រង និងបរិស្ថាន'}
- គោលដៅ៖ ${targetGoals || 'សម្រេចសូចនាករសាលារៀនគំរូ'}

សូមផ្តល់នូវតារាងសកម្មភាពជា JSON Array ដែលមានទម្រង់៖
[
  {
    "id": "act-UUID",
    "activity": "ឈ្មោះសកម្មភាពអនុវត្តជាក់លាក់",
    "indicator": "សូចនាករវាស់វែងសមិទ្ធផល (លទ្ធផលរំពឹងទុក)",
    "timeline": "កាលបរិច្ឆេទ (ឧ. ត្រីមាសទី ១, ខែវិច្ឆិកា, ប្រចាំខែ...)",
    "budget": "ថវិកាប៉ាន់ស្មាន (ឧ. ១,៥០០,០០០ រៀល ឬ ៤០០ ដុល្លារ)",
    "budgetSource": "ប្រភពថវិកា (ឧ. ថវិកា PB / ថវិការដ្ឋ / សហគមន៍ / ដៃគូ)",
    "responsiblePerson": "អ្នកទទួលខុសត្រូវ (ឧ. គណៈគ្រប់គ្រង / គ្រូបន្ទុកថ្នាក់ / គណៈកម្មការ)"
  }
]
សូមផ្តល់យ៉ាងតិច ៦ ទៅ ៨ សកម្មភាពដែលគ្រប់ជ្រុងជ្រោយ និងឆ្លើយតបនឹងអាទិភាព។ ឆ្លើយតបជា JSON សុទ្ធ។`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: KHMER_PLAN_SYSTEM_INSTRUCTION,
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '[]';
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      const cleaned = text.replace(/```json/gi, '').replace(/```/gi, '').trim();
      data = JSON.parse(cleaned);
    }

    res.json({ success: true, actionMatrix: data });
  } catch (error: any) {
    console.error('Error generating matrix:', error);
    res.status(500).json({ success: false, error: error.message || 'បរាជ័យក្នុងការបង្កើតតារាងសកម្មភាព' });
  }
});

// Endpoint: AI Quick Assistant / Text Improver
app.post('/api/plan/quick-assist', async (req: Request, res: Response) => {
  try {
    const { text, promptType, customInstruction } = req.body;

    let task = '';
    if (promptType === 'fix_grammar') task = 'សូមពិនិត្យអក្ខរាវិរុទ្ធ និងវេយ្យាករណ៍ខ្មែរ ដោយកែពាក្យខុសឱ្យត្រូវតាមក្បួនខ្នាតរដ្ឋបាល។';
    else if (promptType === 'more_formal') task = 'សូមកែសម្រួលឃ្លាប្រយោគឱ្យកាន់តែផ្លូវការ បែបគរុកោសល្យ និងភាសារដ្ឋបាលជាន់ខ្ពស់។';
    else if (promptType === 'bullet_points') task = 'សូមរៀបចំខ្លឹមសារនេះជាទម្រង់ចំណុចៗ (Bullet points) ងាយស្រួលអាន និងមានសណ្ដាប់ធ្នាប់។';
    else if (promptType === 'custom') task = customInstruction;
    else task = 'សូមកែលម្អខ្លឹមសារនេះឱ្យកាន់តែប្រសើរ និងពេញលេញ។';

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `អត្ថបទដើម៖
${text}

កិច្ចការ៖
${task}

សូមឆ្លើយតបតែអត្ថបទលទ្ធផលសុទ្ធ។`,
      config: {
        systemInstruction: KHMER_PLAN_SYSTEM_INSTRUCTION,
      },
    });

    res.json({ success: true, result: response.text });
  } catch (error: any) {
    console.error('Error in quick assist:', error);
    res.status(500).json({ success: false, error: error.message || 'បរាជ័យក្នុងការដំណើរការ' });
  }
});

// Static files and Vite integration
if (process.env.NODE_ENV !== 'production') {
  const { createServer } = await import('vite');
  const vite = await createServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (_req: Request, res: Response) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
}

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
